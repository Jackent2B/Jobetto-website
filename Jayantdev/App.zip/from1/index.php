<!DOCTYPE html>
<html lang="en" xmlns="http://www.w3.org/1999/xhtml" class="bit-no-js">

<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->
<head><meta charset="utf-8" /><title>
	Upload Resume for Job, Submit your CV, Submit Resume | Randstad India
</title><meta name="viewport" content="width=device-width, initial-scale=1" /><meta name="msapplication-config" content="none" /><script src="../../c/customs/log/log.js"></script><link href="https://www.randstad.in/App_Themes/HumanForward/css?v=cVaKcQSAHXetgrI4wYSLc6Qxw1_SGTCpo-e3bFFXzao1" rel="stylesheet"/>
<link href="https://www.randstad.in/App_Themes/MyRandstadV2/css?v=3yS5u3mXMbyP4Yw532Nd47NmLeOlHQ33zC6GQdhN4041" rel="stylesheet"/>
<script type="text/javascript" src="https://www.randstad.in/bundles/jquery?v=iDqcwg1pkzK1enRJYGae9RDhjeqY4RCSbFJnHcxhctM1"></script><script src="../../../cdn.optimizely.com/js/10519950310.js"></script><script type="text/javascript">window.dataLayer = window.dataLayer || []; dataLayer.push({"version":"1.0.3","page":{"environment":"DEV","country":"IN","language":"en","type":"account","virtual_page":"","breadcrumb":[],"breadcrumb_checkout":[],"search_result_amount":0.00,"search_result_distance":0.00,"search_result_page":0.00,"search_result_zip_code":"","search_result_keyword":"","custom":{"ecommerce_indicator":null}},"user":{"employee_number":"","type":"","signup_date":"","login_status":"guest","no_of_applications":0.00,"consent_given":false,"custom":{"account_id":""}},"gtm_ip_address":"196.195.189.90"});</script>
<!--Start of Zopim Live Chat Script-->
<script type="text/javascript">
window.$zopim||(function(d,s){var z=$zopim=function(c){
z._.push(c)},$=z.s=
d.createElement(s),e=d.getElementsByTagName(s)[0];z.set=function(o){z.set.
_.push(o)};z._=[];z.set._=[];$.async=!0;$.setAttribute('charset','utf-8');
$.src='http://v2.zopim.com/?45lVjLmXzsXaDMwOG5l8sKrvS9jzhfDt';z.t=+new Date;$.
type='text/javascript';e.parentNode.insertBefore($,e)})(document,'script');
</script>
<!--End of Zopim Live Chat Script-->
<!-- Facebook Pixel Code -->
<script>
!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
document,'script','../../../connect.facebook.net/en_US/fbevents.js');
fbq('init', '1488290164719280'); // Insert your pixel ID here.
fbq('track', 'PageView');
</script>
<!-- DO NOT MODIFY -->
<!-- End Facebook Pixel Code --><script type="text/javascript">(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src='../../../www.googletagmanager.com/gtm5445.html?id='+i+dl;f.parentNode.insertBefore(j,f);})(window, document, 'script', 'dataLayer', 'GTM-MMD9J43');</script><meta name="description" content="Submit your resume for job at Randstad, Register and upload your CV for job opportunities." /><link rel="stylesheet" type="text/css" href="body%7bfont-size_16px%3b%7d.html" /><link href="https://www.randstad.in/WebResource.axd?d=hcXDZhXiidgsQUtEo5iT3z8lcRv-y9r6C6UAcSeI6O7W-yC0ltwr66XXumB57aaoscyev4yceV8vv0iattB1i9P1eyG86DoU6p1hK5CdOBl9vSZkb65cZvaxA-Lu_i-1lSmeS37Rt2qagJns34Dzc37UZNRBPRxMnnqxtgZcme41&amp;t=636342377574383830" type="text/css" rel="stylesheet" /><script type="text/javascript"  src="../../c/customs/validation/cmsfileuploadvalidator.js"></script>
<link href="../../c/css/CmsFileUploadValidator.css" rel="preload" as="style" onload="this.onload=null;this.rel='stylesheet'"/></head>
<body id="BodyWrapper">
    
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-MMD9J43" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    
    <form method="post" action="verification.php" onsubmit="javascript:return WebForm_OnSubmit();" id="Form1" enctype="multipart/form-data">
<div class="aspNetHidden">
<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="" />
<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="" />
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="w3NUTrNjFgKePd34la05KhiEeRKQSIk2l/3hGiFi/YN08iVKxYpVlhbERt5ESJsDPVJNtBNMMOztPrfZjcuxil6tQBf9agE3RexTixljoQ4kxZrmye7jXvyMLX1n1oOKIxZ5f5nYlCn8mSLuYJ2yId7tc1bDNCBGjhXtgRxsJ0KrFsC6NzmB2+IuS822v4TLdS02iYmkSdtR1ixsiNvnRiuMm05gQQW+F2N9XOYRRrCcyrqhWYhOMwHRCJ7Ph7WXSrwXgnovPEohvFbjlVIU38Oj1/NU5N7ToqIjbtelYTWXwEFFYddkcuSUOfdXppQdShlWnM5UgU2PYeWa+OBaiRiQi3X/vZLbaNPI5zRaq62zbQ5ZTAGvwfIQkPTsyKIMH7mv+4kRu4Sz2w9EG8My4IU/3I9Grrzy/6DNHrf3P9ZCmAOyRZt2vDqprdBGcY0ElrN4mq4mRq3Jq0yr+pqCtCEBPr3P/gvPr8ERZHWyb1XtMu0nZtztAQorKL+JpcuRTXOkYUF3RPIAHCy+BivfuGE5Q4Johc/3kVaNa97Eg4fMp7/wQkMQ2EAN2Uz+jKf/KU394QCpo0UvBxh7CcQ5VjQX/5Y7Yp9qAtDbWaAMAqCyrj1beBMLW2iUhteA4DUQiGd/xOwhN4cz5Efl8bEjztdl5nhscoRO8oxY9xPGopUehO6wba92ecT9sogsyz41X38+IBb5tE/vFeyc2TIWhSUGUJPNcmLk1R5nD/7R6X+Nx0h9bXMUv2JqselRrXMAHawUYW3OisCJwAF6VTeNWMF62TGWttmOmhU7Kz6eo6+SZCvD2AuPnnX+QdetxST4TsBHWa+oR6B9JnA9h194wQvb4GhuzuO7DB/ymIX0wkqXccC0EPRc998iYVRsxAkI4fSo+i7RgvWUxEe+uVDdr34GOpmpPHTWFPSo5zQrbiLiFoDUhRWBEqXh+m/5/iHkRiKu3PRF/U1oDarc+TC55livbsc0jjKDhdAcK5qSxsIgPEK9J30AJ/RZ675FJRxo2fD7JNHX/iD08CcK9ZVVNiEdOUQ1NayUVo9GP/uXtZ40f28H/r5UVgEM50Gql31XPfuXUTDZ/ENxX7c/RjPxQ7nk2PO2v2/Gllk7zNgkZOVgmdygJvupnoSRcIvVn9k5MIkJB4Ps4E9jBNZssxowO0vXWyOJg9oSOuDRJ1fT+28p6p90GU51TXSDDm1BE9eGbPdB+HzIFdIegxJIkksnM+2j2KlO9S0Od3xqntS6f8MREPsj4N74clw877kBjY+t" />
</div>

<script type="text/javascript">
//<![CDATA[
var theForm = document.forms['Form1'];
if (!theForm) {
    theForm = document.Form1;
}
function __doPostBack(eventTarget, eventArgument) {
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
        theForm.__EVENTTARGET.value = eventTarget;
        theForm.__EVENTARGUMENT.value = eventArgument;
        theForm.submit();
    }
}
//]]>
</script>



<script src="https://www.randstad.in/ScriptResource.axd?d=nv7asgRUU0tRmHNR2D6t1Ad6UINoXrXuEvBLqTieLJwwFgHqGdl8wGwWk_46l7LSUk1h9CK4sfsVpav06Dk2dWtQAb7fONStneZfiLVxUu1Ud8ogkkjDIiQ-ToFkbroxVDrBP9ux3t9t8DU9AcnbzQ2&amp;t=29665526" type="text/javascript"></script>
<script src="https://www.randstad.in/ScriptResource.axd?d=vTFkWNX2eNyb8c5dcEWBOWt8Apko25oS7UwFhloQDUQRq9DLS8p2YTcR4-X52Pkk9rPdhGRhoasMRHMWibf9CxxDAfd0CGxFNu2rcL0cXsEB5SRsqTkgtcK-yJ4nZajDbJbBYOo0GbhHieTY0MhxUcPHv0TTkNbiED1vSk1nd23E6ZM3ubDJd9kP2NuzDR8X5PWS4Hf14_aLXchr13jO3YWNlAhTU5vCNP-0rTbpZPTem7TCad19_wFx5SEZm59JW3cBWDMyCykv4uF9jzCp1SL2_uUGzXTLxvShrtMqc5rm6Hr6ipHuc52ehy4hdY0kRK-DXbvEzL60HwHVgujJ-X7eokfJ2KThLIesi98pZrdiiGsBrkF-83Nu-SC0s5kbBsP9ltMlhcH56U77gxzXlqXZNAGLfJhSEb-RSxVvfwY98oc-uV2Rhv2rKBMXvrjHOK5U3WHwKSDdAU3uOIFY_A2" type="text/javascript"></script>
<script src="https://www.randstad.in/ScriptResource.axd?d=dwY9oWetJoJoVpgL6Zq8OCzj3JL4Sq8mcJWalCFxZXJYBH96U76F7qEgif8QPp37pNgiQ5ydOl4EW_fmRPQBrtk67nGDAdnYfsQ8rgv1OZgYu_W732ILidvnv0nwCAQqjw_vfVrbbwmPI4Q-5oUj_7bc7WuIRvg3bOxpXmHgSow1&amp;t=ffffffff999c3159" type="text/javascript"></script>
<script src="../../c/customs/validation/cmslinkbutton.js" type="text/javascript"></script>
<script src="../../c/s/jquery.loaded.js" type="text/javascript"></script>
<script src="https://www.randstad.in/bundles/general?v=OlROaRAV-WFfBkn0Ew9H4Wpxg6Q5ELlcXKfDEE7a69c1" type="text/javascript"></script>
<script src="../../CustomScripts/Forms/formRegisterData.js" type="text/javascript"></script>
<script src="https://www.randstad.in/ScriptResource.axd?d=X6kQKInQS5YQqruiTh57iMCEWEQXetzy8xsPtTFNCw9vSdtPg3Wy-YqbXOL1uEMxpPuh1kmTbcIPPLjAh1W9X6I2qqlbxEZRQpdw5B2VrMBNo2Kvqwca9GTVBZBNzNWE0&amp;t=ffffffff8fe80928" type="text/javascript"></script>
<script type="text/javascript">
//<![CDATA[
function WebForm_OnSubmit() {
null;if (typeof(ValidatorOnSubmit) == "function" && ValidatorOnSubmit() == false) return false;
return true;
}
//]]>
</script>

<div class="aspNetHidden">

	<input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="FCB7707C" />
	<input type="hidden" name="__VIEWSTATEENCRYPTED" id="__VIEWSTATEENCRYPTED" value="" />
</div>
        <script type="text/javascript">
//<![CDATA[
Sys.WebForms.PageRequestManager._initialize('ctl05', 'Form1', [], [], [], 90, '');
//]]>
</script>

        
        




<header class="masthead sb-slide box">
    <div class="masthead-top box-inner">
        
        
        
        
<ul class="list-clean nav-utility">
    <li>
        <label class="float-right nav-handler sb-toggle-right has-bg-img"></label>
    </li>
    <li class="hide-for-xlarge quick-login-small">
        <a id="ctl08_ctl01_ctl00_MyRandstadHyperLink" class="hide-for-xlarge my-randstad-login-small has-bg-img" href=""></a></li>
    
            
          
        
   
</ul>

        
        <a id="ctl08_ctl01_HomeHyperLink" class="logo-randstad" href="">
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 205 30.64"><title>Register</title><path class="a" d="M15.95,30.32H20.5V18.87a2.26,2.26,0,0,0-.67-1.62l-6.75-6.75a2.25,2.25,0,0,0-1.62-.67H0v4.56H12.53a3.42,3.42,0,0,1,3.42,3.42Z" transform="translate(0 -0.18)"/><path class="a" d="M27.28,30.32H22.72V18.87a2.26,2.26,0,0,1,.67-1.62l6.75-6.75a2.25,2.25,0,0,1,1.62-.67H43.22v4.56H30.69a3.42,3.42,0,0,0-3.42,3.42Z" transform="translate(0 -0.18)"/><path class="a" d="M63.8,9.82h3.52V13h.08a6.24,6.24,0,0,1,5.34-3.66,10.69,10.69,0,0,1,2.49.28V13a5.6,5.6,0,0,0-2.09-.36c-3.38,0-5.59,3.22-5.59,8.37v9.33H63.8Z" transform="translate(0 -0.18)"/><path class="a" d="M179.24,22.35c0,3.09-2,5.44-5.7,5.44-1.72,0-3.81-1.18-3.81-3.36,0-3.65,5.06-4,7.1-4,.8,0,1.6.08,2.41.08Zm-11-7.87a9.52,9.52,0,0,1,5.94-2.13c3.77,0,5.05,1.84,5.05,5.38-1.48-.08-2.53-.08-4-.08-3.89,0-9.52,1.6-9.52,6.75,0,4.5,3.1,6.42,7.51,6.42a7.6,7.6,0,0,0,6.34-3.11h.08v2.61H183V17.79c0-5.6-2.36-8.47-8.21-8.47A13.1,13.1,0,0,0,168,11.24Z" transform="translate(0 -0.18)"/><path class="a" d="M88,22.35c0,3.09-2,5.44-5.7,5.44-1.73,0-3.81-1.18-3.81-3.36,0-3.65,5.06-4,7.1-4,.8,0,1.6.08,2.41.08ZM77,14.48A9.52,9.52,0,0,1,83,12.35c3.77,0,5.06,1.84,5.06,5.38-1.48-.08-2.53-.08-4-.08-3.89,0-9.52,1.6-9.52,6.75,0,4.5,3.1,6.42,7.51,6.42a7.6,7.6,0,0,0,6.34-3.11h.08v2.61H91.8V17.79c0-5.6-2.36-8.47-8.21-8.47a13.1,13.1,0,0,0-6.74,1.92Z" transform="translate(0 -0.18)"/><path class="a" d="M94.88,9.82h3.64V13h.08a7.39,7.39,0,0,1,6.73-3.72c5.31,0,7.66,3.28,7.66,8.79V30.32h-3.76V19.69c0-4.79-1-7.13-4.35-7.33-4.31,0-6.24,3.47-6.24,8.48v9.48H94.88Z" transform="translate(0 -0.18)"/><path class="a" d="M137.55,26.33a10.06,10.06,0,0,0,4.7,1.45c1.72,0,3.85-.73,3.85-2.95,0-3.76-8.87-3.43-8.87-9.21,0-4.27,3.18-6.31,7.23-6.31a15.49,15.49,0,0,1,4.7.81l-.32,3.27a11,11,0,0,0-4-1.05c-1.92,0-3.61.81-3.61,2.51,0,4.2,8.87,3,8.87,9.58,0,4.39-3.5,6.39-7.15,6.39a11.84,11.84,0,0,1-5.62-1.12Z" transform="translate(0 -0.18)"/><path class="a" d="M164.48,12.85h-5.43V24.11c0,2.38,1.45,3.67,3.17,3.67a4.65,4.65,0,0,0,2.57-.73v3.2a11.94,11.94,0,0,1-3.21.56c-3.89,0-6.29-1.83-6.29-5.94v-12h-4.62v-3h4.62V5.08l3.76-1.2V9.82h5.43Z" transform="translate(0 -0.18)"/><path class="a" d="M189.56,20c-.08-3.76,1.53-7.64,5.62-7.64s6.06,3.92,6.06,7.76c0,3.43-1.77,7.68-6,7.68C191.17,27.79,189.48,23.22,189.56,20ZM201.4,30.32H205V.18h-3.76V12.6h-.08C200,10.72,198,9.32,194.38,9.32c-5.94,0-8.84,4.85-8.84,10.37s2.61,11.13,8.8,11.13a8.22,8.22,0,0,0,7-3.36h.08Z" transform="translate(0 -0.18)"/><path class="a" d="M119.57,20c-.08-3.76,1.53-7.64,5.62-7.64s6.06,3.92,6.06,7.76c0,3.43-1.77,7.68-6,7.68C121.17,27.79,119.48,23.22,119.57,20Zm11.84,10.33H135V.18h-3.76V12.6h-.08C130,10.72,128,9.32,124.38,9.32c-5.94,0-8.84,4.85-8.84,10.37s2.61,11.13,8.8,11.13a8.22,8.22,0,0,0,7-3.36h.08Z" transform="translate(0 -0.18)"/></svg>
        </a>
        
        <!--<div class="nav-main2">
            
                    <ul class="cf list-clean hide-for-small hide-for-medium hide-for-large">
                        
                    <li id="ctl08_ctl01_MenuListView_ctrl0_ItemLI">
                        <a id="ctl08_ctl01_MenuListView_ctrl0_ItemHyperLink" href="https://www.randstad.in/job-seeker/">job seeker</a></li>
                
                    <li id="ctl08_ctl01_MenuListView_ctrl1_ItemLI">
                        <a id="ctl08_ctl01_MenuListView_ctrl1_ItemHyperLink" href="https://www.randstad.in/employers/">employers</a></li>
                
                    <li id="ctl08_ctl01_MenuListView_ctrl2_ItemLI">
                        <a id="ctl08_ctl01_MenuListView_ctrl2_ItemHyperLink" href="https://www.randstad.in/about-us/">about us</a></li>
                
                    <li id="ctl08_ctl01_MenuListView_ctrl3_ItemLI">
                        <a id="ctl08_ctl01_MenuListView_ctrl3_ItemHyperLink" href="https://www.randstad.in/join-our-team/">join our team</a></li>
                
                    <li id="ctl08_ctl01_MenuListView_ctrl4_ItemLI">
                        <a id="ctl08_ctl01_MenuListView_ctrl4_ItemHyperLink" href="https://www.randstad.in/workforce360/">workforce360</a></li>
                
                    
                
                    <li id="ctl08_ctl01_MenuListView_ctrl6_ItemLI">
                        <a id="ctl08_ctl01_MenuListView_ctrl6_ItemHyperLink" href="https://www.randstad.in/employer-brand-research/">employer brand research</a></li>
                
                    <li id="ctl08_ctl01_MenuListView_ctrl7_ItemLI">
                        <a id="ctl08_ctl01_MenuListView_ctrl7_ItemHyperLink" href="https://www.randstad.in/randstad-insights/">randstad insights</a></li>
                
                    <li id="ctl08_ctl01_MenuListView_ctrl8_ItemLI">
                        <a id="ctl08_ctl01_MenuListView_ctrl8_ItemHyperLink" href="https://www.randstad.in/futurist-chro/">futurist chro</a></li>
                
                    </ul>
                
        </div>-->
    </div>
    
   <!-- <nav class="nav-menu-bar">
        <div class="nav-menu-bar-inner box-inner">
            <div class="nav-menu-squares">
                
                        <ul class="list-clean">
                            
                        <li>
                            <a id="ctl08_ctl01_SubMenuListView_ctrl0_ItemHyperLink" href="https://www.randstad.in/my-randstad/my-randstad/">my Randstad</a></li>
                    
                        <li>
                            <a id="ctl08_ctl01_SubMenuListView_ctrl1_ItemHyperLink" href="https://www.randstad.in/my-randstad/my-profile/">my profile</a></li>
                    
                        <li>
                            <a id="ctl08_ctl01_SubMenuListView_ctrl2_ItemHyperLink" href="https://www.randstad.in/jobs/" target="_self">find a job</a></li>
                    
                        <li>
                            <a id="ctl08_ctl01_SubMenuListView_ctrl3_ItemHyperLink" href="https://www.randstad.in/job-seeker/career-hub/" target="_self">career hub</a></li>
                    
                        <li>
                            <a id="ctl08_ctl01_SubMenuListView_ctrl4_ItemHyperLink" href="https://www.randstad.in/job-seeker/areas-of-expertise/" target="_self">areas of expertise</a></li>
                    
                        <li>
                            <a id="ctl08_ctl01_SubMenuListView_ctrl5_ItemHyperLink" href="https://www.randstad.in/job-seeker/our-offices/" target="_self">our offices</a></li>
                    
                        </ul>
                    
            </div>
        </div>
    </nav>-->
</header>




<script type="text/javascript">
    $(document).ready(function () {
        renderQuickLogin();
    });
</script>







<div id="ctl08_ctl02_PanelWrapper" class="my-randstad-login-panel" onkeypress="javascript:return WebForm_FireDefaultButton(event, &#39;ctl08_ctl02_LoginButton&#39;)">
	

    <div id="ctl08_ctl02_LogInWrapper" class="my-randstad-login-panel--inner">
        <span id="ctl08_ctl02_TitleLabel" class="quick-login--header">login to my Randstad</span>
        <span id="FailureTextLabel" class="field-error"></span>
        <ol class="list-clean">
            <li class="my-randstad-login-panel-field">
                <label for="ctl08_ctl02_UserNameTextBox" id="ctl08_ctl02_UserNameLabel">Email address (username)</label>
                <input name="mail" type="text" id="ctl08_ctl02_UserNameTextBox" />
                <span id="ctl08_ctl02_UserNameRequired" title="Email address (username) is required" class="field-error" style="display:none;">Email address (username) is required</span>
                <input type="hidden" name="ctl08$ctl02$UserNameWatermarkExtender_ClientState" id="ctl08_ctl02_UserNameWatermarkExtender_ClientState" />
            </li>
            <li class="my-randstad-login-panel-field">
                <label for="ctl08_ctl02_PasswordTextBox" id="ctl08_ctl02_PasswordLabel">Password</label>
                <input name="pass" type="password" id="ctl08_ctl02_PasswordTextBox" Placeholder="password" />
                <span id="ctl08_ctl02_PasswordRequired" title="Password is required" class="field-error" style="display:none;">Password is required</span>
            </li>
            <li class="quick-login--forgot-password">
                <a id="ctl08_ctl02_ForgotPasswordHyperLink" class="has-bg-img-after quick-login-more" href="https://www.randstad.in/my-randstad/forgot-password/">I forgot my password</a></li>
            <li class="quick-login--btn">
                <a id="ctl08_ctl02_LoginButton" class="btn btn-prim btn-full" href="javascript:WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;ctl08$ctl02$LoginButton&quot;, &quot;&quot;, true, &quot;SimpleLoginPanel&quot;, &quot;&quot;, false, true))">login</a>
            </li>
            <li class="quick-login--register">
                <a id="ctl08_ctl02_RegisterHyperLink" class="has-bg-img-after quick-login-more" href="index.html">register for a free account</a></li>
        </ol>
    </div>
    

</div>




<div class="box-inner breadcrumb-languages">
    <nav id="ctl08_ctl03_BreadCrumbNav" class="breadcrumb sb-slide hide-for-small">
        <a href="https://www.randstad.in/">home</a><span> / </span><a href="https://www.randstad.in/my-randstad/">my Randstad</a><span> / </span><span>register</span>
    </nav>
    <script type="application/ld+json">{"@context":"http:\/\/schema.org","@type":"BreadcrumbList","itemListElement":[{"@type":"ListItem","item":{"@id":"\/","name":"home"},"position":1},{"@type":"ListItem","item":{"@id":"\/my-randstad\/","name":"my Randstad"},"position":2},{"@type":"ListItem","item":{"@id":null,"name":"register"},"position":3}]}</script>
</div>




<div id="sb-site">
        
    <div id="ctl08_ContentWrapper" class="main">
        <noscript class="no-script-box">
            <div class="box-inner">
                <span id="ctl08_NoScriptTitleLabel" class="no-script-box-header">Warning: Javascript disabled</span>
                <p>
                    Note: our system indicates that Javascript is disabled or not supported by your browser. In order to take advantage of full functionality of this site, javascript must be enabled. Please change your browser options.
                </p>
            </div>
        </noscript>
        
        
        

        <div id="ctl08_OneColumnDiv" class="box-content cf">
            
            <a id="skipnav"></a>
            <div id="ctl08_OneColumnInnerDiv">
          



<!--- Form Starts Here -- By Mayank Agrawak -->		  

<div id="ctl08_ctl04_LayoutDiv" class="register-wrapper" data-bit-validateform="register">
    <div class="my-randstad-header-panel">
        <div class="box-inner">
            <h1 id="ctl08_ctl04_RegisterHeader">
                
            </h1>
            
        </div>
    </div>
    <div class="box-inner">
        
    </div>
    <div id="ctl08_ctl04_RegisterFormDiv" class="box-inner cms-profile-account-wrapper half-padding">
        <h4 class="title">
            Account information</h4>
        <div id="ctl08_ctl04_FormValidationSummary" class="nfc-negative form-errors has-bg-img-before" style="display:none;">

</div>
        <ol class="list-clean form">
       
            <li class="form-field">

                <span id="ctl08_ctl04_RequiredFieldsLabel">Fields marked with * are required fields</span>
            </li>
            <li class="form-field">
                <label for="ctl08_ctl04_EmailTextBox" id="ctl08_ctl04_EmailLabel" class="is-required">email</label>
                <div class="form-element">
                    <input name="email" type="email" maxlength="250" id="ctl08_ctl04_EmailTextBox" class="form-control" data-bit-id="EmailTextBox" data-bit-validate="email" placeholder="email" />
                    <span id="ctl08_ctl04_EmailValidator" class="field-error" style="display:none;">email is required</span>
                    <span id="ctl08_ctl04_EmailInvalidValidator" class="field-error" style="display:none;">email is invalid</span>
                    <span id="ctl08_ctl04_ExistingAccountLabel" class="hidden field-error" data-bit-show="ExistingUserEmail">An account with this email address is already registered. <a href="https://www.randstad.in/my-randstad/">Click here to login</a></span>
                </div>
            </li>
            <li class="form-field">
                <label for="ctl08_ctl04_EmailRetypeTextBox" id="ctl08_ctl04_EmailRetypeLabel" class="is-required">re-type email</label>
                <div class="form-element">
                    <input name="ctl08$ctl04$EmailRetypeTextBox" type="text" autocomplete="off" maxlength="250" id="ctl08_ctl04_EmailRetypeTextBox" placeholder="re-type email" />
                    <span id="ctl08_ctl04_EmailRetypeValidator" class="field-error" style="display:none;">re-type email is required</span>
                    <span id="ctl08_ctl04_EmailCompareValidator" class="field-error" style="display:none;">the re-typed email doesn't match your first entry</span>
                </div>
            </li>
            <li class="form-field">
                <label for="ctl08_ctl04_PasswordTextBox" id="ctl08_ctl04_PasswordLabel" class="is-required">password</label>
                <div class="form-element">
                    <input name="password" type="password" maxlength="100" id="ctl08_ctl04_PasswordTextBox" data-bit-validate-on-change="" placeholder="password" Value="" />
                    <span id="ctl08_ctl04_PasswordRequiredValidator" class="field-error" style="display:none;">password is required</span>
                                    </div>
            </li>
            <li id="ctl08_ctl04_PasswordDescriptionWrapper" class="form-field">
                <div class="form-control-description">
                    <span id="ctl08_ctl04_PasswordIntroLabel">Password must </span>
                    <span id="ctl08_ctl04_PasswordRequireLengthValidator" class="field-visible" style="display:none;">be at least 6 character long </span>
                    <span id="ctl08_ctl04_PasswordRequireOneDigitValidator" class="field-visible" style="display:none;">including one digit (“09”), </span>
                    <span id="ctl08_ctl04_PasswordRequireNonLetterOrDigitValidator" class="field-visible" style="display:none;">one non letter character (!@#$%) and </span>
                    <span id="ctl08_ctl04_PasswordRequireUpperCaseValidator" class="field-visible" style="display:none;">at least one uppercase (“AZ”) </span>
                    <span id="ctl08_ctl04_PasswordRequireLowerCaseValidator" class="field-visible" style="display:none;">and lowercase (“az”)</span>
                    <span id="ctl08_ctl04_PasswordOutroLiteral">.</span>
                </div>
            </li>
            <li class="form-field">
                <label for="ctl08_ctl04_PasswordRetypeTextBox" id="ctl08_ctl04_PasswordRetypeLabel" class="is-required">re-type password</label>
                <div class="form-element">
                    <input name="ctl08$ctl04$PasswordRetypeTextBox" type="password" maxlength="100" id="ctl08_ctl04_PasswordRetypeTextBox" data-bit-validate-on-change="" placeholder="re-type password" Value="" />
                    <span id="ctl08_ctl04_PasswordRetypeRequiredValidator" class="field-error" style="display:none;">re-type password is required</span>
                    <span id="ctl08_ctl04_PasswordCompareValidator" class="field-error" style="display:none;">the re-typed password doesn't match your first entry</span>
                </div>
            </li>
        </ol>
    </div>
    <div class="box-inner cms-profile-account-wrapper half-padding">
        <h4 class="title">
            Personal information</h4>
        <ol class="list-clean form">
            <li class="form-field">
                <label for="ctl08_ctl04_FirstNameTextBox" id="ctl08_ctl04_FirstNameTextBoxLabel" class="is-required">first name</label>
                <div class="form-element">
                    <input name="firstname" type="text" maxlength="80" id="ctl08_ctl04_FirstNameTextBox" placeholder="first name" />
                    <span id="ctl08_ctl04_FirstNameValidator" class="field-error" style="display:none;">first name is required</span>
                </div>
            </li>
            <li class="form-field">
                <label for="ctl08_ctl04_LastNameTextBox" id="ctl08_ctl04_LastNameTextBoxLabel" class="is-required">last name</label>
                <div class="form-element">
                    <input name="lastname" type="text" maxlength="80" id="ctl08_ctl04_LastNameTextBox" placeholder="last name" />
                    <span id="ctl08_ctl04_LastNameValidator" class="field-error" style="display:none;">last name is required</span>
                </div>
            </li>
            <li class="form-field">
                <label for="ctl08_ctl04_PhoneMobileTextBox" id="ctl08_ctl04_PhoneMobileLabel" class="is-required">phone (mobile)</label>
                <div class="form-element">
                    <input name="number" type="text" maxlength="30" id="ctl08_ctl04_PhoneMobileTextBox" placeholder="phone (mobile)" data-bit-validate="phone" />
                    <span id="ctl08_ctl04_PhoneMobileInstructionsLabel" class="input-field-description-label">10-digit mobile number without prefixes</span>
                    <span id="ctl08_ctl04_PhoneMobileValidator" class="field-error" style="display:none;">phone (mobile) is required</span>
                    <span id="ctl08_ctl04_PhoneMobileRegexValidator" class="field-error" style="display:none;">phone (mobile) is invalid</span>
                    <span id="ctl08_ctl04_ExistingAccountPhoneLabel" class="hidden field-error" data-bit-show="ExistingUserPhone">An account with this phone number is already registered. <a href="https://www.randstad.in/my-randstad/">Click here to login</a></span>
                </div>
            </li>
            <li class="form-field">
                <label for="ctl08_ctl04_CityDropDownList" id="ctl08_ctl04_CityLabel" class="is-required">city</label>
                <div class="form-element">
                    <select name="city" id="ctl08_ctl04_CityDropDownList">
	<option value="-1">-- please select --</option>
	<option value="Agartala">Agartala</option>
	<option value="Agra">Agra</option>
	<option value="Ahmadnagar">Ahmadnagar</option>
	<option value="Ahmedabad">Ahmedabad</option>
	<option value="Allahabad">Allahabad</option>
	<option value="Amritsar">Amritsar</option>
	<option value="Anand">Anand</option>
	<option value="Anugul">Anugul</option>
	<option value="Asansol">Asansol</option>
	<option value="Aurangabad">Aurangabad</option>
	<option value="Belgaum">Belgaum</option>
	<option value="Bellary">Bellary</option>
	<option value="Bengaluru / Bangalore">Bengaluru / Bangalore</option>
	<option value="Bharuch">Bharuch</option>
	<option value="Bhopal">Bhopal</option>
	<option value="Bhubaneswar">Bhubaneswar</option>
	<option value="Chandigarh">Chandigarh</option>
	<option value="Chandrapur">Chandrapur</option>
	<option value="Chennai">Chennai</option>
	<option value="Chittoor">Chittoor</option>
	<option value="Coimbatore">Coimbatore</option>
	<option value="Cuttack">Cuttack</option>
	<option value="Dahod">Dahod</option>
	<option value="Daman">Daman</option>
	<option value="Dehradun">Dehradun</option>
	<option value="Delhi">Delhi</option>
	<option value="Delhi / NCR">Delhi / NCR</option>
	<option value="Dindigul">Dindigul</option>
	<option value="Ernakulam">Ernakulam</option>
	<option value="Faizabad">Faizabad</option>
	<option value="Faridabad">Faridabad</option>
	<option value="Ghaziabad">Ghaziabad</option>
	<option value="Gurgaon">Gurgaon</option>
	<option value="Guwahati">Guwahati</option>
	<option value="Gwalior">Gwalior</option>
	<option value="Haldia">Haldia</option>
	<option value="Hardwar">Hardwar</option>
	<option value="Hubli">Hubli</option>
	<option value="Hyderabad / Secunderabad">Hyderabad / Secunderabad</option>
	<option value="Indore">Indore</option>
	<option value="Itanagar">Itanagar</option>
	<option value="Jabalpur">Jabalpur</option>
	<option value="Jaipur">Jaipur</option>
	<option value="Jajpur">Jajpur</option>
	<option value="Jammu">Jammu</option>
	<option value="Jamnagar">Jamnagar</option>
	<option value="Jamshedpur">Jamshedpur</option>
	<option value="Jharsuguda">Jharsuguda</option>
	<option value="Kancheepuram">Kancheepuram</option>
	<option value="Kanniyakumari">Kanniyakumari</option>
	<option value="Kanpur">Kanpur</option>
	<option value="Kolhapur">Kolhapur</option>
	<option value="Kolkata">Kolkata</option>
	<option value="Kollam">Kollam</option>
	<option value="Kottayam">Kottayam</option>
	<option value="Kozhikode">Kozhikode</option>
	<option value="Lucknow">Lucknow</option>
	<option value="Ludhiana">Ludhiana</option>
	<option value="Madurai">Madurai</option>
	<option value="Mangalore">Mangalore</option>
	<option value="Medak">Medak</option>
	<option value="Medinipur">Medinipur</option>
	<option value="Mumbai">Mumbai</option>
	<option value="Mundra">Mundra</option>
	<option value="Mysore">Mysore</option>
	<option value="Nagercoil">Nagercoil</option>
	<option value="Nagpur">Nagpur</option>
	<option value="Nainital">Nainital</option>
	<option value="Nashik">Nashik</option>
	<option value="Noida">Noida</option>
	<option value="North Goa">North Goa</option>
	<option value="Palakkad">Palakkad</option>
	<option value="Panch Mahals">Panch Mahals</option>
	<option value="Patna">Patna</option>
	<option value="Pondicherry">Pondicherry</option>
	<option value="Pune">Pune</option>
	<option value="Raipur">Raipur</option>
	<option value="Rajkot">Rajkot</option>
	<option value="Ranchi">Ranchi</option>
	<option value="Rangpo">Rangpo</option>
	<option value="Rudrapur">Rudrapur</option>
	<option value="Salem">Salem</option>
	<option value="Shillong">Shillong</option>
	<option value="Shimla">Shimla</option>
	<option value="Silvassa">Silvassa</option>
	<option value="Solapur">Solapur</option>
	<option value="South Goa">South Goa</option>
	<option value="Srinagar">Srinagar</option>
	<option value="Surat">Surat</option>
	<option value="Thanjavur">Thanjavur</option>
	<option value="Thiruvallur">Thiruvallur</option>
	<option value="Thiruvananthapuram">Thiruvananthapuram</option>
	<option value="Thrissur">Thrissur</option>
	<option value="Tiruchirappalli">Tiruchirappalli</option>
	<option value="Tirunelveli">Tirunelveli</option>
	<option value="Tiruvannamalai">Tiruvannamalai</option>
	<option value="Tuticorin">Tuticorin</option>
	<option value="Vadodara">Vadodara</option>
	<option value="Valsad">Valsad</option>
	<option value="Vapi">Vapi</option>
	<option value="Vellore">Vellore</option>
	<option value="Vijayawada">Vijayawada</option>
	<option value="Visakhapatnam">Visakhapatnam</option>

</select>
                    <span id="ctl08_ctl04_CityValidator" class="field-error" style="display:none;">city is required</span>
                </div>
            </li>
            <li class="form-field">
                <label for="ctl08_ctl04_IndustryDropDownList" id="ctl08_ctl04_IndustryLabel" class="is-required">industry</label>
                <div class="form-element">
                    <select name="industry" id="ctl08_ctl04_IndustryDropDownList">
	<option value="-1">-- please select --</option>
	<option value="Accounting / Finance">Accounting / Finance</option>
	<option value="Advertising / PR / MR / Events">Advertising / PR / MR / Events</option>
	<option value="Agriculture / Diary">Agriculture / Diary</option>
	<option value="Airlines">Airlines</option>
	<option value="Animation">Animation</option>
	<option value="Architecture / Interior Design">Architecture / Interior Design</option>
	<option value="Auto / Auto Ancillary">Auto / Auto Ancillary</option>
	<option value="Aviation / Aerospace Firm">Aviation / Aerospace Firm</option>
	<option value="Banking / Financial Services / Broking / Asset Management">Banking / Financial Services / Broking / Asset Management</option>
	<option value="BPO / ITES">BPO / ITES</option>
	<option value="Brewery / Distillery">Brewery / Distillery</option>
	<option value="Broadcasting">Broadcasting</option>
	<option value="Cement">Cement</option>
	<option value="Ceramics / Sanitary Ware">Ceramics / Sanitary Ware</option>
	<option value="Chemicals / PetroChemical">Chemicals / PetroChemical</option>
	<option value="Construction">Construction</option>
	<option value="Consumer Durables">Consumer Durables</option>
	<option value="Courier / Transportation / Freight">Courier / Transportation / Freight</option>
	<option value="Defence / Government">Defence / Government</option>
	<option value="Education / Teaching / Training">Education / Teaching / Training</option>
	<option value="Electricals / Switchgears">Electricals / Switchgears</option>
	<option value="Engineering / Heavy Engg. / EPC">Engineering / Heavy Engg. / EPC</option>
	<option value="Export / Import">Export / Import</option>
	<option value="Facility Management">Facility Management</option>
	<option value="Fertilizers / Pesticides">Fertilizers / Pesticides</option>
	<option value="FMCG / Foods / Beverage">FMCG / Foods / Beverage</option>
	<option value="Food Processing">Food Processing</option>
	<option value="Gems &amp; Jewellery">Gems &amp; Jewellery</option>
	<option value="Glass">Glass</option>
	<option value="Heat Ventilation Air Conditioning">Heat Ventilation Air Conditioning</option>
	<option value="Hotels / Restaurants / Hospitality">Hotels / Restaurants / Hospitality</option>
	<option value="Industrial Products / Heavy Machinery">Industrial Products / Heavy Machinery</option>
	<option value="Infrastructure">Infrastructure</option>
	<option value="Insurance">Insurance</option>
	<option value="Internet / Ecommerce">Internet / Ecommerce</option>
	<option value="IT-Hardware &amp; Networking">IT-Hardware &amp; Networking</option>
	<option value="IT-Software / Software Services">IT-Software / Software Services</option>
	<option value="KPO / Research / Analytics">KPO / Research / Analytics</option>
	<option value="Leather">Leather</option>
	<option value="Legal">Legal</option>
	<option value="Media / Dotcom / Entertainment">Media / Dotcom / Entertainment</option>
	<option value="Medical / Healthcare / Hospital">Medical / Healthcare / Hospital</option>
	<option value="Medical Devices / Equipments">Medical Devices / Equipments</option>
	<option value="Metals">Metals</option>
	<option value="Mining">Mining</option>
	<option value="NGO / Social Services">NGO / Social Services</option>
	<option value="Office Equipment / Automation">Office Equipment / Automation</option>
	<option value="Oil and Gas">Oil and Gas</option>
	<option value="Paper">Paper</option>
	<option value="Pharma / Biotech / Clinical Research">Pharma / Biotech / Clinical Research</option>
	<option value="Plastics">Plastics</option>
	<option value="Power / Energy / Non conventional Energy">Power / Energy / Non conventional Energy</option>
	<option value="Printing / Packaging">Printing / Packaging</option>
	<option value="Private Equity / Venture Capitalists / Incubators">Private Equity / Venture Capitalists / Incubators</option>
	<option value="Publishing">Publishing</option>
	<option value="Real Estate / Property">Real Estate / Property</option>
	<option value="Recruitment / HR services">Recruitment / HR services</option>
	<option value="Retail">Retail</option>
	<option value="Rubber">Rubber</option>
	<option value="Security / Law Enforcement">Security / Law Enforcement</option>
	<option value="Semiconductors / Electronics">Semiconductors / Electronics</option>
	<option value="Shipping / Marine">Shipping / Marine</option>
	<option value="Steel">Steel</option>
	<option value="Strategy / Management Consulting Firms">Strategy / Management Consulting Firms</option>
	<option value="Sugar">Sugar</option>
	<option value="Telecom / ISP">Telecom / ISP</option>
	<option value="Textiles / Garments / Accessories">Textiles / Garments / Accessories</option>
	<option value="Travel &amp; Tourism">Travel &amp; Tourism</option>
	<option value="Tyres">Tyres</option>
	<option value="Water Treatment /  Waste Management">Water Treatment /  Waste Management</option>
	<option value="Wellness / Fitness / Sports">Wellness / Fitness / Sports</option>

</select>
                    <span id="ctl08_ctl04_IndustryValidator" class="field-error" style="display:none;">industry is required</span>
                </div>
            </li>
            <li class="form-field">
                <label for="ctl08_ctl04_CategoryDropDownList" id="ctl08_ctl04_CategoryLabel" class="is-required">function</label>
                <div class="form-element">
                    <select name="company" id="ctl08_ctl04_CategoryDropDownList">
	<option value="-1">-- please select --</option>
	<option value="Accounting / Tax / Company Secretary / Audit">Accounting / Tax / Company Secretary / Audit</option>
	<option value="Agent">Agent</option>
	<option value="Airline / Reservations / Ticketing / Travel">Airline / Reservations / Ticketing / Travel</option>
	<option value="Analytics &amp; Business Intelligence">Analytics &amp; Business Intelligence</option>
	<option value="Anchoring / TV / Films / Production">Anchoring / TV / Films / Production</option>
	<option value="Architects / Interior Design / Naval Arch.">Architects / Interior Design / Naval Arch.</option>
	<option value="Art Director / Graphic / Web Designer">Art Director / Graphic / Web Designer</option>
	<option value="Banking / Insurance">Banking / Insurance</option>
	<option value="Beauty / Fitness / Spa Services">Beauty / Fitness / Spa Services</option>
	<option value="Content / Journalism">Content / Journalism</option>
	<option value="Corporate Planning / Consulting">Corporate Planning / Consulting</option>
	<option value="CSR &amp; Sustainability">CSR &amp; Sustainability</option>
	<option value="Engineering Design / R&amp;D">Engineering Design / R&amp;D</option>
	<option value="Export / Import / Merchandising">Export / Import / Merchandising</option>
	<option value="Fashion / Garments / Merchandising">Fashion / Garments / Merchandising</option>
	<option value="Guards / Security Services">Guards / Security Services</option>
	<option value="Hotels / Restaurants">Hotels / Restaurants</option>
	<option value="HR / Administration / IR">HR / Administration / IR</option>
	<option value="IT - Hardware / Telecom / Technical Staff / Support">IT - Hardware / Telecom / Technical Staff / Support</option>
	<option value="IT Software - Application Programming / Maintenance">IT Software - Application Programming / Maintenance</option>
	<option value="IT Software - Client Server">IT Software - Client Server</option>
	<option value="IT Software - DBA / Datawarehousing">IT Software - DBA / Datawarehousing</option>
	<option value="IT Software - Ecommerce / Internet Technologies">IT Software - Ecommerce / Internet Technologies</option>
	<option value="IT Software - Embedded /EDA /VLSI /ASIC / Chip Des.">IT Software - Embedded /EDA /VLSI /ASIC / Chip Des.</option>
	<option value="IT Software - ERP / CRM">IT Software - ERP / CRM</option>
	<option value="IT Software - Mainframe">IT Software - Mainframe</option>
	<option value="IT Software - Middleware">IT Software - Middleware</option>
	<option value="IT Software - Mobile">IT Software - Mobile</option>
	<option value="IT Software - Network Administration / Security">IT Software - Network Administration / Security</option>
	<option value="IT Software - QA &amp; Testing">IT Software - QA &amp; Testing</option>
	<option value="IT Software - System Programming">IT Software - System Programming</option>
	<option value="IT Software - Systems / EDP / MIS">IT Software - Systems / EDP / MIS</option>
	<option value="IT Software - Telecom Software">IT Software - Telecom Software</option>
	<option value="ITES / BPO / KPO / Customer Service / Operations">ITES / BPO / KPO / Customer Service / Operations</option>
	<option value="Legal">Legal</option>
	<option value="Marketing / Advertising / MR / PR">Marketing / Advertising / MR / PR</option>
	<option value="Packaging">Packaging</option>
	<option value="Pharma / Biotech / Healthcare / Medical / R&amp;D">Pharma / Biotech / Healthcare / Medical / R&amp;D</option>
	<option value="Production / Maintenance / Quality">Production / Maintenance / Quality</option>
	<option value="Purchase / Logistics / Supply Chain">Purchase / Logistics / Supply Chain</option>
	<option value="Sales / BD">Sales / BD</option>
	<option value="Secretary / Front Office / Data Entry">Secretary / Front Office / Data Entry</option>
	<option value="Self Employed / Consultants">Self Employed / Consultants</option>
	<option value="Shipping">Shipping</option>
	<option value="Site Engineering / Project Management">Site Engineering / Project Management</option>
	<option value="Teaching / Education">Teaching / Education</option>
	<option value="Ticketing / Travel / Airlines">Ticketing / Travel / Airlines</option>
	<option value="Top Management">Top Management</option>
	<option value="TV / Films / Production">TV / Films / Production</option>
	<option value="Web / Graphic Design / Visualiser">Web / Graphic Design / Visualiser</option>

</select>
                    <span id="ctl08_ctl04_CategoryValidator" class="field-error" style="display:none;">function is required</span>
                </div>
            </li>
            <li class="form-field">
                <label for="ctl08_ctl04_QualificationDropDownList" id="ctl08_ctl04_EducationalQuafilicationLabel" class="is-required">highest educational qualification</label>
                <div class="form-element">
                    <select name="educational" id="ctl08_ctl04_QualificationDropDownList">
	<option value="-1">-- please select --</option>
	<option value="B.A">B.A</option>
	<option value="B.Arch">B.Arch</option>
	<option value="B.B.A/ B.M.S">B.B.A/ B.M.S</option>
	<option value="B.Com">B.Com</option>
	<option value="B.Ed">B.Ed</option>
	<option value="B.Pharma">B.Pharma</option>
	<option value="B.Sc">B.Sc</option>
	<option value="B.Tech/B.E.">B.Tech/B.E.</option>
	<option value="BCA">BCA</option>
	<option value="BDS">BDS</option>
	<option value="BVSC">BVSC</option>
	<option value="CA">CA</option>
	<option value="CS">CS</option>
	<option value="Diploma">Diploma</option>
	<option value="H.Sc/+2/Intermediate">H.Sc/+2/Intermediate</option>
	<option value="ICWA (CMA)">ICWA (CMA)</option>
	<option value="ITI">ITI</option>
	<option value="LLB">LLB</option>
	<option value="LLM">LLM</option>
	<option value="M.A">M.A</option>
	<option value="M.Arch">M.Arch</option>
	<option value="M.B.A">M.B.A</option>
	<option value="M.Com">M.Com</option>
	<option value="M.Ed">M.Ed</option>
	<option value="M.Pharma">M.Pharma</option>
	<option value="M.Tech">M.Tech</option>
	<option value="MBBS">MBBS</option>
	<option value="MCA">MCA</option>
	<option value="MDS">MDS</option>
	<option value="Medical-MS/MD">Medical-MS/MD</option>
	<option value="MPHIL">MPHIL</option>
	<option value="MS/M.Sc(Science)">MS/M.Sc(Science)</option>
	<option value="MVSc">MVSc</option>
	<option value="PG Diploma">PG Diploma</option>
	<option value="Ph.D / Doctorate">Ph.D / Doctorate</option>
	<option value="SSLC/10">SSLC/10</option>

</select>
                    <span id="ctl08_ctl04_EducationalQuafilicationValidator" class="field-error" style="display:none;">highest educational qualification is required</span>
                </div>
            </li>
            <li class="form-field">
                <label for="ctl08_ctl04_ExperienceInYearsDropDownList" id="ctl08_ctl04_OverallExperienceLabel" class="is-required">overall experience</label>
                <div class="form-element">
                    <div class="year">
                        <select name="year" id="ctl08_ctl04_ExperienceInYearsDropDownList" class="dropdown-half">
	<option value="-1">years</option>
	<option value="0">0</option>
	<option value="1">1</option>
	<option value="2">2</option>
	<option value="3">3</option>
	<option value="4">4</option>
	<option value="5">5</option>
	<option value="6">6</option>
	<option value="7">7</option>
	<option value="8">8</option>
	<option value="9">9</option>
	<option value="10">10</option>
	<option value="11">11</option>
	<option value="12">12</option>
	<option value="13">13</option>
	<option value="14">14</option>
	<option value="15">15</option>
	<option value="16">16</option>
	<option value="17">17</option>
	<option value="18">18</option>
	<option value="19">19</option>
	<option value="20">20</option>
	<option value="21">21</option>
	<option value="22">22</option>
	<option value="23">23</option>
	<option value="24">24</option>
	<option value="25">25</option>
	<option value="26">26</option>
	<option value="27">27</option>
	<option value="28">28</option>
	<option value="29">29</option>
	<option value="30">30</option>
	<option value="31">31</option>
	<option value="32">32</option>
	<option value="33">33</option>
	<option value="34">34</option>
	<option value="35">35</option>
	<option value="36">36</option>
	<option value="37">37</option>
	<option value="38">38</option>
	<option value="39">39</option>
	<option value="40">40</option>
	<option value="41">41</option>
	<option value="42">42</option>
	<option value="43">43</option>
	<option value="44">44</option>
	<option value="45">45</option>
	<option value="46">46</option>
	<option value="47">47</option>
	<option value="48">48</option>
	<option value="49">49</option>
	<option value="50">50</option>

</select>
                        <select name="month" id="ctl08_ctl04_ExperienceInMonthsDropDownList" class="dropdown-half">
	<option value="-1">months</option>
	<option value="0">0</option>
	<option value="1">1</option>
	<option value="2">2</option>
	<option value="3">3</option>
	<option value="4">4</option>
	<option value="5">5</option>
	<option value="6">6</option>
	<option value="7">7</option>
	<option value="8">8</option>
	<option value="9">9</option>
	<option value="10">10</option>
	<option value="11">11</option>

</select>
                    </div>
                    <span id="ctl08_ctl04_OverallExperienceValidator" class="field-error" style="display:none;">overall experience is required</span>
                </div>
            </li>
            <li class="form-field">
                <label for="ctl08_ctl04_PresentCTCLakhsDropDownList" id="ctl08_ctl04_PresentCTCLabel" class="is-required">present CTC</label>
                <div class="form-element">
                    <div class="form-element form-element-dropdown">
                        <select name="lakhs" id="ctl08_ctl04_PresentCTCLakhsDropDownList" class="dropdown-half">
	<option value="-1">lakhs</option>
	<option value="0">0</option>
	<option value="1">1</option>
	<option value="2">2</option>
	<option value="3">3</option>
	<option value="4">4</option>
	<option value="5">5</option>
	<option value="6">6</option>
	<option value="7">7</option>
	<option value="8">8</option>
	<option value="9">9</option>
	<option value="10">10</option>
	<option value="11">11</option>
	<option value="12">12</option>
	<option value="13">13</option>
	<option value="14">14</option>
	<option value="15">15</option>
	<option value="16">16</option>
	<option value="17">17</option>
	<option value="18">18</option>
	<option value="19">19</option>
	<option value="20">20</option>
	<option value="21">21</option>
	<option value="22">22</option>
	<option value="23">23</option>
	<option value="24">24</option>
	<option value="25">25</option>
	<option value="26">26</option>
	<option value="27">27</option>
	<option value="28">28</option>
	<option value="29">29</option>
	<option value="30">30</option>
	<option value="31">31</option>
	<option value="32">32</option>
	<option value="33">33</option>
	<option value="34">34</option>
	<option value="35">35</option>
	<option value="36">36</option>
	<option value="37">37</option>
	<option value="38">38</option>
	<option value="39">39</option>
	<option value="40">40</option>
	<option value="41">41</option>
	<option value="42">42</option>
	<option value="43">43</option>
	<option value="44">44</option>
	<option value="45">45</option>
	<option value="46">46</option>
	<option value="47">47</option>
	<option value="48">48</option>
	<option value="49">49</option>
	<option value="50">50</option>
	<option value="51">51</option>
	<option value="52">52</option>
	<option value="53">53</option>
	<option value="54">54</option>
	<option value="55">55</option>
	<option value="56">56</option>
	<option value="57">57</option>
	<option value="58">58</option>
	<option value="59">59</option>
	<option value="60">60</option>
	<option value="61">61</option>
	<option value="62">62</option>
	<option value="63">63</option>
	<option value="64">64</option>
	<option value="65">65</option>
	<option value="66">66</option>
	<option value="67">67</option>
	<option value="68">68</option>
	<option value="69">69</option>
	<option value="70">70</option>
	<option value="71">71</option>
	<option value="72">72</option>
	<option value="73">73</option>
	<option value="74">74</option>
	<option value="75">75</option>
	<option value="76">76</option>
	<option value="77">77</option>
	<option value="78">78</option>
	<option value="79">79</option>
	<option value="80">80</option>
	<option value="81">81</option>
	<option value="82">82</option>
	<option value="83">83</option>
	<option value="84">84</option>
	<option value="85">85</option>
	<option value="86">86</option>
	<option value="87">87</option>
	<option value="88">88</option>
	<option value="89">89</option>
	<option value="90">90</option>
	<option value="91">91</option>
	<option value="92">92</option>
	<option value="93">93</option>
	<option value="94">94</option>
	<option value="95">95</option>
	<option value="96">96</option>
	<option value="97">97</option>
	<option value="98">98</option>
	<option value="99">99</option>
	<option value="100">100</option>
	<option value="101">101</option>
	<option value="102">102</option>
	<option value="103">103</option>
	<option value="104">104</option>
	<option value="105">105</option>
	<option value="106">106</option>
	<option value="107">107</option>
	<option value="108">108</option>
	<option value="109">109</option>
	<option value="110">110</option>
	<option value="111">111</option>
	<option value="112">112</option>
	<option value="113">113</option>
	<option value="114">114</option>
	<option value="115">115</option>
	<option value="116">116</option>
	<option value="117">117</option>
	<option value="118">118</option>
	<option value="119">119</option>
	<option value="120">120</option>
	<option value="121">121</option>
	<option value="122">122</option>
	<option value="123">123</option>
	<option value="124">124</option>
	<option value="125">125</option>
	<option value="126">126</option>
	<option value="127">127</option>
	<option value="128">128</option>
	<option value="129">129</option>
	<option value="130">130</option>
	<option value="131">131</option>
	<option value="132">132</option>
	<option value="133">133</option>
	<option value="134">134</option>
	<option value="135">135</option>
	<option value="136">136</option>
	<option value="137">137</option>
	<option value="138">138</option>
	<option value="139">139</option>
	<option value="140">140</option>
	<option value="141">141</option>
	<option value="142">142</option>
	<option value="143">143</option>
	<option value="144">144</option>
	<option value="145">145</option>
	<option value="146">146</option>
	<option value="147">147</option>
	<option value="148">148</option>
	<option value="149">149</option>
	<option value="150">150</option>
	<option value="151">151</option>
	<option value="152">152</option>
	<option value="153">153</option>
	<option value="154">154</option>
	<option value="155">155</option>
	<option value="156">156</option>
	<option value="157">157</option>
	<option value="158">158</option>
	<option value="159">159</option>
	<option value="160">160</option>
	<option value="161">161</option>
	<option value="162">162</option>
	<option value="163">163</option>
	<option value="164">164</option>
	<option value="165">165</option>
	<option value="166">166</option>
	<option value="167">167</option>
	<option value="168">168</option>
	<option value="169">169</option>
	<option value="170">170</option>
	<option value="171">171</option>
	<option value="172">172</option>
	<option value="173">173</option>
	<option value="174">174</option>
	<option value="175">175</option>
	<option value="176">176</option>
	<option value="177">177</option>
	<option value="178">178</option>
	<option value="179">179</option>
	<option value="180">180</option>
	<option value="181">181</option>
	<option value="182">182</option>
	<option value="183">183</option>
	<option value="184">184</option>
	<option value="185">185</option>
	<option value="186">186</option>
	<option value="187">187</option>
	<option value="188">188</option>
	<option value="189">189</option>
	<option value="190">190</option>
	<option value="191">191</option>
	<option value="192">192</option>
	<option value="193">193</option>
	<option value="194">194</option>
	<option value="195">195</option>
	<option value="196">196</option>
	<option value="197">197</option>
	<option value="198">198</option>
	<option value="199">199</option>
	<option value="200">200</option>

</select>
                        <select name="thousands" id=" " class="dropdown-half">
	<option value="-1">thousands</option>
	<option value="0">0</option>
	<option value="1">1</option>
	<option value="2">2</option>
	<option value="3">3</option>
	<option value="4">4</option>
	<option value="5">5</option>
	<option value="6">6</option>
	<option value="7">7</option>
	<option value="8">8</option>
	<option value="9">9</option>
	<option value="10">10</option>
	<option value="11">11</option>
	<option value="12">12</option>
	<option value="13">13</option>
	<option value="14">14</option>
	<option value="15">15</option>
	<option value="16">16</option>
	<option value="17">17</option>
	<option value="18">18</option>
	<option value="19">19</option>
	<option value="20">20</option>
	<option value="21">21</option>
	<option value="22">22</option>
	<option value="23">23</option>
	<option value="24">24</option>
	<option value="25">25</option>
	<option value="26">26</option>
	<option value="27">27</option>
	<option value="28">28</option>
	<option value="29">29</option>
	<option value="30">30</option>
	<option value="31">31</option>
	<option value="32">32</option>
	<option value="33">33</option>
	<option value="34">34</option>
	<option value="35">35</option>
	<option value="36">36</option>
	<option value="37">37</option>
	<option value="38">38</option>
	<option value="39">39</option>
	<option value="40">40</option>
	<option value="41">41</option>
	<option value="42">42</option>
	<option value="43">43</option>
	<option value="44">44</option>
	<option value="45">45</option>
	<option value="46">46</option>
	<option value="47">47</option>
	<option value="48">48</option>
	<option value="49">49</option>
	<option value="50">50</option>
	<option value="51">51</option>
	<option value="52">52</option>
	<option value="53">53</option>
	<option value="54">54</option>
	<option value="55">55</option>
	<option value="56">56</option>
	<option value="57">57</option>
	<option value="58">58</option>
	<option value="59">59</option>
	<option value="60">60</option>
	<option value="61">61</option>
	<option value="62">62</option>
	<option value="63">63</option>
	<option value="64">64</option>
	<option value="65">65</option>
	<option value="66">66</option>
	<option value="67">67</option>
	<option value="68">68</option>
	<option value="69">69</option>
	<option value="70">70</option>
	<option value="71">71</option>
	<option value="72">72</option>
	<option value="73">73</option>
	<option value="74">74</option>
	<option value="75">75</option>
	<option value="76">76</option>
	<option value="77">77</option>
	<option value="78">78</option>
	<option value="79">79</option>
	<option value="80">80</option>
	<option value="81">81</option>
	<option value="82">82</option>
	<option value="83">83</option>
	<option value="84">84</option>
	<option value="85">85</option>
	<option value="86">86</option>
	<option value="87">87</option>
	<option value="88">88</option>
	<option value="89">89</option>
	<option value="90">90</option>
	<option value="91">91</option>
	<option value="92">92</option>
	<option value="93">93</option>
	<option value="94">94</option>
	<option value="95">95</option>
	<option value="96">96</option>
	<option value="97">97</option>
	<option value="98">98</option>
	<option value="99">99</option>

</select>
                        <span id="ctl08_ctl04_PresentCTCLakhsValidator" class="field-error" style="display:none;">lakhs is required</span>
                        <span id="ctl08_ctl04_PresentCTCThousandsValidator" class="field-error" style="display:none;">thousands is required</span>
                    </div>
                </div>
            </li>
            <li class="form-field job-apply-cv-upload">
                <label for="ctl08_ctl04_CVFileUpload" id="ctl08_ctl04_CvLabel" class="jbs-apply-form-lbl cv-file-upload is-required">CV</label>
                <div class="form-element">
                    <div class="custom-file-upload">
                        <div class="custom-file-upload-toggle">
                            <div class="custom-file-upload-toggle-btn btn btn-prim">
                                choose file
                            </div>
                        </div>
                        <input type="file" name="cv" id="ctl08_ctl04_CVFileUpload" class="custom-file-upload-input" data-bit-id="cvFileUpload" />
                    </div>
                    <span data-bit-output-upload-files="cvFileUpload"></span>
                    <div>
                        <ul class="cms-icons cms-icons-valid">
	<li><span title="Valid extensions:.pdf" class="cms-icon cms-icon-pdf"></span></li><li><span title="Valid extensions:.doc, .docx, .rtf, .txt" class="cms-icon cms-icon-text"></span></li>
</ul>
<!--<span class="cms-fileupload-validator-information cms-fileupload-validator-information-filesize">Max. 3 MB.</span>  -->
<div id="ctl08_ctl04_CVFileUploadValidator" class="cms-file-upload-validator field-error" style="display:none;">
	<span class="cms-file-upload-validator-error-message">CV is required</span>
</div> 
                    </div>
                </div>
            </li>
           <!-- <li class="form-field">
                <label for="ctl08_ctl04_TermsAndConditionsCheckBox" id="ctl08_ctl04_TermsAndConditionsCheckBoxLabel" class="is-required">terms</label>
                <div class="form-element">
                    <span class="receive-mail-job-check-box"><input id="ctl08_ctl04_TermsAndConditionsCheckBox" type="checkbox" name="ctl08$ctl04$TermsAndConditionsCheckBox" checked="checked" /><label for="ctl08_ctl04_TermsAndConditionsCheckBox">I accept the <a href='https://www.randstad.in/terms-and-conditions/' target='_blank'>Terms & Conditions</a></label></span> 
                    <span id="ctl08_ctl04_TermsAndConditionsValidator" style="display:none;">terms is required</span>
                </div>
            </li> -->
            
            
            </form>
        </ol>

        <div class="cf button-wrapper">
          <input type="submit" name="submit" value="Submit">
        </div>
    </div>
</div>



<!--- Form ENDS Here -- By Mayank Agrawak -->
                
                
                
                
                
                
                
                
                
              
                </header></form>
                
            </div>
        </div>
        
        
        
        

<div>
    <footer class="cf footer-main">
        <div class="box-inner">
            
<!--            <div id="ctl08_ctl05_FooterDiv" class="grid-wrap">
                        
                        
                                <div class="footer-main-col">
                                    <div class="footer-main-col-inner">
                                        
                                <div class="footer-link-list">
                                    <div>
                                        <span class="footer-list-header footer-list-header-toggle has-bg-img-after">
                                            job seeker
                                        </span>
                                        
                                                <ul class="list-clean footer-link-list-sub">
                                                    
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/" target="_self">find a job</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="index.html" target="_self">submit your cv</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/job-seeker/areas-of-expertise/" target="_self">areas of expertise</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/job-seeker/career-hub/" target="_self">career hub</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/job-seeker/our-offices/" target="_self">our offices</a>
                                                </li>
                                            
                                                </ul>
                                            
                                    </div>
                                    
                                </div>
                            
                                <div class="footer-link-list">
                                    <div>
                                        <span class="footer-list-header footer-list-header-toggle has-bg-img-after">
                                            jobs by industry / function
                                        </span>
                                        
                                                <ul class="list-clean footer-link-list-sub">
                                                    
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/s-agro-seeds/" target="_self">jobs in agro and seeds</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/s-construction-property/" target="_self">jobs in construction & property</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/s-consumer-durables-electronics/" target="_self">jobs in consumer durables and electronics</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/s-education/" target="_self">jobs in education</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/s-fmcg/" target="_self">jobs in fmcg</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/s-banking-finance/" target="_self">jobs in banking & finance</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/s-oil-gas-power-energy/" target="_self">jobs in oil, gas, power & energy</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/q-hr/" target="_self">jobs in HR</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/s-information-technology/" target="_self">jobs in IT</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/s-consulting-vc/" target="_self">jobs in consulting & vc</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/s-other/" target="_self">jobs in other</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/s-ites-bpo/" target="_self">jobs in ITeS and BPO</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/s-legal-regulatory-intellectual-property/" target="_self">jobs in legal & intellectual property</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/s-manufacturing/" target="_self">jobs in manufacturing and industrial</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/s-digital-marketing-communication/" target="_self">jobs in digital marketing and communication</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/s-pharma-healthcare-lifesciences/" target="_self">jobs in pharma and healthcare</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/s-retail/" target="_self">jobs in retail</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/q-sales/" target="_self">jobs in sales</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/s-telecom/" target="_self">jobs in telecom</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/s-supply-chain-logistics/" target="_self">jobs in supply chain and logistics</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/job-seeker/jobs-by-industry-city/" target="_self">jobs by Industry / city</a>
                                                </li>
                                            
                                                </ul>
                                            
                                    </div>
                                    
                                </div>
                            
                                    </div>
                                </div>
                            
                    
                        
                                <div class="footer-main-col">
                                    <div class="footer-main-col-inner">
                                        
                                <div class="footer-link-list">
                                    <div>
                                        <span class="footer-list-header footer-list-header-toggle has-bg-img-after">
                                            jobs by location
                                        </span>
                                        
                                                <ul class="list-clean footer-link-list-sub">
                                                    
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/gujarat/ahmedabad/" target="_self">jobs in Ahmedabad</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/karnataka/bengaluru/" target="_self">jobs in Bangalore</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/tamil-nadu/coimbatore/" target="_self">jobs in Coimbatore</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/rajasthan/jaipur/" target="_self">jobs in Jaipur</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/maharashtra/mumbai/" target="_self">jobs in Mumbai</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/gujarat/vadodara/" target="_self">jobs in Vadodara</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/haryana/gurgaon/" target="_self">jobs in Gurgaon</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/jharkhand/jamshedpur/" target="_self">jobs in Jamshedpur</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/bihar/patna/" target="_self">jobs in Patna</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/tamil-nadu/chennai/" target="_self">jobs in Chennai</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/orissa/bhubaneswar/" target="_self">jobs in Bhubaneswar</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/telangana/hyderabad/" target="_self">jobs in Hyderabad</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/assam/guwahati/" target="_self">jobs in Guwahati</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/tamil-nadu/vellore/" target="_self">jobs in Vellore</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/west-bengal/kolkata/" target="_self">jobs in Kolkata</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/maharashtra/nagpur/" target="_self">jobs in Nagpur</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/maharashtra/pune/" target="_self">jobs in Pune</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/uttar-pradesh/kanpur/" target="_self">jobs in Kanpur</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/chandigarh/" target="_self">jobs in Chandigarh</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/madhya-pradesh/indore/" target="_self">jobs in Indore</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/gujarat/bharuch/" target="_self">jobs in Bharuch</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/karnataka/hubli/" target="_self">jobs in Hubli</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/uttar-pradesh/lucknow/" target="_self">jobs in Lucknow</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/new-delhi/" target="_self">jobs in Delhi</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/gujarat/rajkot/" target="_self">jobs in Rajkot</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/andhra-pradesh/visakhapatnam/" target="_self">jobs in Visakhapatnam</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/gujarat/surat/" target="_self">jobs in Surat</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/andhra-pradesh/vijayawada/" target="_self">jobs in Vijayawada</a>
                                                </li>
                                            
                                                </ul>
                                            
                                    </div>
                                    
                                </div>
                            
                                    </div>
                                </div>
                            
                    
                        
                                <div class="footer-main-col">
                                    <div class="footer-main-col-inner">
                                        
                                <div class="footer-link-list">
                                    <div>
                                        <span class="footer-list-header footer-list-header-toggle has-bg-img-after">
                                            employers
                                        </span>
                                        
                                                <ul class="list-clean footer-link-list-sub">
                                                    
                                                <li>
                                                    <a href="https://www.randstad.in/employers/submit-a-job/" target="_self">submit a job</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/employers/request-a-call-back/" target="_self">request a call back</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/employers/areas-of-expertise/" target="_self">areas of expertise</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/employers/our-solutions/" target="_self">our solutions</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/employers/our-offices/" target="_self">our offices</a>
                                                </li>
                                            
                                                </ul>
                                            
                                    </div>
                                    
                                </div>
                            
                                <div class="footer-link-list">
                                    <div>
                                        <span class="footer-list-header footer-list-header-toggle has-bg-img-after">
                                            our solutions
                                        </span>
                                        
                                                <ul class="list-clean footer-link-list-sub">
                                                    
                                                <li>
                                                    <a href="https://www.randstad.in/employers/our-solutions/permanent-recruitment/" target="_self">permanent recruitment</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/employers/our-solutions/recruitment-process-outsourcing/" target="_self">recruitment process outsourcing</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/employers/our-solutions/general-staffing/" target="_self">general staffing</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/employers/our-solutions/specialty-staffing/" target="_self">specialty staffing</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/employers/our-solutions/executive-search/" target="_self">executive search</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/employers/our-solutions/headhunters/" target="_self">headhunting</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/employers/our-solutions/manpower-consultancy/" target="_self">manpower consultancy</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/employers/our-solutions/talent-acquisition-and-management-specialist/" target="_self">talent acquisition</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/employers/our-solutions/payroll-services/" target="_self">payroll transfer services</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/employers/our-solutions/sales-and-trade-marketing/" target="_self">sales and trade marketing</a>
                                                </li>
                                            
                                                </ul>
                                            
                                    </div>
                                    
                                </div>
                            
                                <div class="footer-link-list">
                                    <div>
                                        <span class="footer-list-header footer-list-header-toggle has-bg-img-after">
                                            areas of expertise
                                        </span>
                                        
                                                <ul class="list-clean footer-link-list-sub">
                                                    
                                                <li>
                                                    <a href="https://www.randstad.in/employers/areas-of-expertise/analytics-and-data-sciences/" target="_self">analytics and data sciences</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/employers/areas-of-expertise/banking-and-financial-services/" target="_self">banking and financial services</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/employers/areas-of-expertise/civil-and-architecture/" target="_self">civil and architecture</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/employers/areas-of-expertise/operations-logistics-and-supply-chain/" target="_self">operations logistics and supply chain</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/employers/areas-of-expertise/product-management-and-information-technology/" target="_self">product management and information technology</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/employers/areas-of-expertise/sales-and-account-management/" target="_self">sales and account management</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/employers/areas-of-expertise/pharma-life-sciences-healthcare/" target="_self">pharma and healthcare</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/employers/areas-of-expertise/support-functions/" target="_self">support functions</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/employers/areas-of-expertise/hr-recruitment/" target="_self">human resource</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/employers/areas-of-expertise/construction-recruitment/" target="_self">construction recruitment</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/employers/areas-of-expertise/manufacturing-staffing/" target="_self">manufacturing staffing</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/employers/areas-of-expertise/fmcg-recruitment/" target="_self">fmcg recruitment</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/employers/areas-of-expertise/bpo-recruitment/" target="_self">bpo recruitment</a>
                                                </li>
                                            
                                                </ul>
                                            
                                    </div>
                                    
                                </div>
                            
                                    </div>
                                </div>
                            
                    
                        
                                <div class="footer-main-col">
                                    <div class="footer-main-col-inner">
                                        
                                <div class="footer-link-list">
                                    <div>
                                        <span class="footer-list-header footer-list-header-toggle has-bg-img-after">
                                            about us
                                        </span>
                                        
                                                <ul class="list-clean footer-link-list-sub">
                                                    
                                                <li>
                                                    <a href="https://www.randstad.in/about-us/our-history/" target="_self">our history</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/about-us/our-sponsorships/" target="_self">our sponsorships</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/about-us/social-responsibility/" target="_self">social responsibility</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/about-us/press-releases/" target="_self">press releases</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/about-us/randstad-in-the-news/" target="_self">Randstad in the news</a>
                                                </li>
                                            
                                                </ul>
                                            
                                    </div>
                                    
                                </div>
                            
                                <div class="footer-link-list">
                                    <div>
                                        <span class="footer-list-header footer-list-header-toggle has-bg-img-after">
                                            career hub
                                        </span>
                                        
                                                <ul class="list-clean footer-link-list-sub">
                                                    
                                                <li>
                                                    <a href="https://www.randstad.in/job-seeker/career-hub/archives/" target="_self">archives</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/job-seeker/career-hub/archives/?th=93" target="_self">building your career</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/job-seeker/career-hub/archives/?th=94" target="_self">cv and interview advice</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/job-seeker/career-hub/archives/?th=95" target="_self">finding the right job</a>
                                                </li>
                                            
                                                </ul>
                                            
                                    </div>
                                    
                                </div>
                            
                                <div class="footer-link-list">
                                    <div>
                                        <span class="footer-list-header footer-list-header-toggle has-bg-img-after">
                                            join our team
                                        </span>
                                        
                                                <ul class="list-clean footer-link-list-sub">
                                                    
                                                <li>
                                                    <a href="https://www.randstad.in/job-seeker/our-offices/" target="_self">our offices</a>
                                                </li>
                                            
                                                </ul>
                                            
                                    </div>
                                    
                                </div>
                            
                                <div class="footer-link-list">
                                    <div>
                                        <span class="footer-list-header footer-list-header-toggle has-bg-img-after">
                                            workforce360
                                        </span>
                                        
                                                <ul class="list-clean footer-link-list-sub">
                                                    
                                                <li>
                                                    <a href="https://www.randstad.in/workforce360/archives/?th=90" target="_self">strategic talent management</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/workforce360/archives/?th=5" target="_self">HR & leadership</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/workforce360/archives/?th=6" target="_self">flexibility & labour market</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/employer-brand-research/employer-branding/" target="_self">employer branding</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/workforce360/archives/" target="_self">archives</a>
                                                </li>
                                            
                                                </ul>
                                            
                                    </div>
                                    
                                </div>
                            
                                <div class="footer-link-list">
                                    <div>
                                        <span class="footer-list-header footer-list-header-toggle has-bg-img-after">
                                            women at work
                                        </span>
                                        
                                                <ul class="list-clean footer-link-list-sub">
                                                    
                                                <li>
                                                    <a href="https://www.randstad.in/women-at-work/voices/" target="_self">voices</a>
                                                </li>
                                            
                                                </ul>
                                            
                                    </div>
                                    
                                </div>
                            
                                    </div>
                                </div>
                            
                    
                    </div>-->
          <!--  <div class="footer-main-col footer-search">
                <div class="searchbar">
                    <div id="ctl08_ctl05_ctl01_Panel1" class="quick-search-wrapper" onkeypress="javascript:return WebForm_FireDefaultButton(event, &#39;ctl08_ctl05_ctl01_SearchButton&#39;)">
	
    <label for="ctl08_ctl05_ctl01_SearchTextBox" id="ctl08_ctl05_ctl01_SearchTextBoxLabel"></label>
    <input name="ctl08$ctl05$ctl01$SearchTextBox" type="text" maxlength="100" id="ctl08_ctl05_ctl01_SearchTextBox" class="QuickSearchInput" placeholder="search this site" />
    <a id="ctl08_ctl05_ctl01_SearchButton" class="btn btn-prim icon-arrow-right" href="javascript:__doPostBack(&#39;ctl08$ctl05$ctl01$SearchButton&#39;,&#39;&#39;)">search</a>
    

</div>

                </div>
            </div>-->
           <!-- <div class="footer-main-custom-wrapper">
                <div class="prim-social-bar prim-social-bar-small">
                    <ul class="list-clean">
                        <li id="ctl08_ctl05_LinkedinLi">
                            <a id="ctl08_ctl05_LinkedinHyperLink" class="li has-bg-img has-bg-img-before" href="https://www.linkedin.com/company/2554444/" target="_blank">LinkedIn</a>
                        </li>
                        <li id="ctl08_ctl05_YoutubeLi">
                            <a id="ctl08_ctl05_YoutubeHyperLink" class="yt has-bg-img has-bg-img-before" href="https://www.youtube.com/channel/UCzgSePqFizttduqTo8iq9tA" target="_blank">Youtube</a>
                        </li>
                        <li id="ctl08_ctl05_FacebookLi">
                            <a id="ctl08_ctl05_FacebookHyperLink" class="fb has-bg-img has-bg-img-before" href="https://www.facebook.com/RandstadIndia/" target="_blank">Facebook</a>
                        </li>
                        <li id="ctl08_ctl05_TwitterLi">
                            <a id="ctl08_ctl05_TwitterHyperLink" class="tw has-bg-img has-bg-img-before" href="https://twitter.com/RandstadIndia" target="_blank">Twitter</a>
                        </li>
                        
                        
                        
                        
                    </ul>
                </div>
                <div id="ctl08_ctl05_FooterAdditionalLinksWrapper" class="footer-main-custom">
                            <ul class="footer-link-list list-clean">
                                
                            <li>
                                <a href="https://www.randstad.in/terms-and-conditions/" target="_self">terms & conditions</a>
                            </li>
                        
                            <li>
                                <a href="https://www.randstad.in/contact-us/" target="_self">contact us</a>
                            </li>
                        
                            <li>
                                <a href="https://www.randstad.in/c/Unknown.aspx" target="_self">cookies</a>
                            </li>
                        
                            <li>
                                <a href="https://www.randstad.in/privacy-statement/" target="_self">data protection statement</a>
                            </li>
                        
                            <li>
                                <a href="https://www.randstad.in/misconduct-reporting-procedure/" target="_self">misconduct reporting procedure</a>
                            </li>
                        
                            <li>
                                <a href="https://www.randstad.in/be-aware/" target="_self">be aware</a>
                            </li>
                        
                            <li>
                                <a href="https://www.randstad.in/sitemap/" target="_self">sitemap</a>
                            </li>
                        
                            </ul>
                        </div>
            </div>-->
         <!--   <div class="trade-mark-wrapper">
                <div id="ctl08_ctl05_ctl02_WrapperDiv" class="html-loader-div ">
    
    
    <p>registered office:&nbsp;Randstad India&nbsp;Private Limited, CIN U74210TN1992PTC023097, /&nbsp;Randstad House, Old No. 5 &amp; 5A, New No. 9,&nbsp;Pycrofts Garden Road,&nbsp;Nungambakkam,&nbsp;Chennai&nbsp;TAMIL NADU, INDIA - 600 006&nbsp;&nbsp;&nbsp; &nbsp;</p>
<p>RANDSTAD, <img alt="" src="../../ugc/img/about/randstad_wings_100px.png" style="height: 10px;" />, HUMAN FORWARD and SHAPING THE WORLD OF WORK are registered trademarks of &copy; Randstad N.V.2019</p>
<p><span style="font-size: 0.875em;">Security Advice :</span></p>
<p>
Randstad India does not charge any fee at any stage of its recruitment process from the candidate nor allows their employees to collect any fees from any candidates.
<a href="https://www.randstad.in/job-seeker/security-advice/" title="Security Advice">Click here to know more</a>&nbsp;</p>
<div>&nbsp;</div>
    
</div>

                <a href="https://www.bitagency.com/" target="_blank" title="Development and Hosting by Bit Agency - new window" class="footer-link-greyed-out">Development and Hosting by Bit Agency</a>
            </div>-->
        </div>
    </footer>
</div>

    </div>
</div>



<div class="sb-slidebar sb-right sb-width-custom sb-style">
    
    
            <ul class="nav-global-small list-clean" data-bit-mobile-menu="">
                
            <li>
                <a href="https://www.randstad.in/job-seeker/">job seeker</a>
                
                        <span class="nav-global-small-toggle has-bg-img">toggle</span>
                        <ul class="list-clean nav-global-small-sub">
                            
                        <li>
                            <a href="https://www.randstad.in/jobs/" target="_self">find a job</a>
                        </li>
                    
                        <li>
                            <a href="index.html" target="_self">submit your CV</a>
                        </li>
                    
                        <li>
                            <a href="https://www.randstad.in/job-seeker/career-hub/">career hub</a>
                        </li>
                    
                        <li>
                            <a href="https://www.randstad.in/job-seeker/areas-of-expertise/">areas of expertise</a>
                        </li>
                    
                        <li>
                            <a href="https://www.randstad.in/job-seeker/our-offices/">our offices</a>
                        </li>
                    
                        <li>
                            <a href="https://www.randstad.in/job-seeker/security-advice/">security advice</a>
                        </li>
                    
                        </ul>
                    
            </li>
        
            <li>
                <a href="https://www.randstad.in/employers/">employers</a>
                
                        <span class="nav-global-small-toggle has-bg-img">toggle</span>
                        <ul class="list-clean nav-global-small-sub">
                            
                        <li>
                            <a href="https://www.randstad.in/employers/submit-a-job/">submit a job</a>
                        </li>
                    
                        <li>
                            <a href="https://www.randstad.in/employers/request-a-call-back/">request a call back</a>
                        </li>
                    
                        <li>
                            <a href="https://www.randstad.in/employers/areas-of-expertise/">areas of expertise</a>
                        </li>
                    
                        <li>
                            <a href="https://www.randstad.in/employers/our-offices/">our offices</a>
                        </li>
                    
                        <li>
                            <a href="https://www.randstad.in/employers/randstad-insights/">randstad insights</a>
                        </li>
                    
                        </ul>
                    
            </li>
        
            <li>
                <a href="https://www.randstad.in/about-us/">about us</a>
                
                        <span class="nav-global-small-toggle has-bg-img">toggle</span>
                        <ul class="list-clean nav-global-small-sub">
                            
                        <li>
                            <a href="https://www.randstad.in/about-us/our-history/">our history</a>
                        </li>
                    
                        <li>
                            <a href="https://www.randstad.in/about-us/our-sponsorships/">our sponsorships</a>
                        </li>
                    
                        <li>
                            <a href="https://www.randstad.in/about-us/social-responsibility/">social responsibility</a>
                        </li>
                    
                        <li>
                            <a href="https://www.randstad.in/about-us/press-releases/">press releases</a>
                        </li>
                    
                        <li>
                            <a href="https://www.randstad.in/about-us/randstad-in-the-news/">randstad in the news</a>
                        </li>
                    
                        </ul>
                    
            </li>
        
            <li>
                <a href="https://www.randstad.in/join-our-team/">join our team</a>
                
            </li>
        
            <li>
                <a href="https://www.randstad.in/workforce360/">workforce360</a>
                
                        <span class="nav-global-small-toggle has-bg-img">toggle</span>
                        <ul class="list-clean nav-global-small-sub">
                            
                        <li>
                            <a href="https://www.randstad.in/workforce360/archives/?th=90" target="_self">strategic talent management</a>
                        </li>
                    
                        <li>
                            <a href="https://www.randstad.in/workforce360/archives/?th=5" target="_self">HR & leadership</a>
                        </li>
                    
                        <li>
                            <a href="https://www.randstad.in/workforce360/archives/?th=6" target="_self">flexibility & labour market</a>
                        </li>
                    
                        <li>
                            <a href="https://www.randstad.in/workforce360/archives/?th=7" target="_self">employer branding</a>
                        </li>
                    
                        <li>
                            <a href="https://www.randstad.in/workforce360/events/">events</a>
                        </li>
                    
                        <li>
                            <a href="https://www.randstad.in/workforce360/archives/">archives</a>
                        </li>
                    
                        </ul>
                    
            </li>
        
            <li>
                <a href="https://www.randstad.in/my-randstad/">my Randstad</a>
                
                        <span class="nav-global-small-toggle has-bg-img">toggle</span>
                        <ul class="list-clean nav-global-small-sub">
                            
                        <li>
                            <a href="https://www.randstad.in/my-randstad/my-randstad/">my Randstad</a>
                        </li>
                    
                        <li>
                            <a href="https://www.randstad.in/my-randstad/my-profile/">my profile</a>
                        </li>
                    
                        <li>
                            <a href="https://www.randstad.in/jobs/" target="_self">find a job</a>
                        </li>
                    
                        <li>
                            <a href="https://www.randstad.in/job-seeker/career-hub/" target="_self">career hub</a>
                        </li>
                    
                        <li>
                            <a href="https://www.randstad.in/job-seeker/areas-of-expertise/" target="_self">areas of expertise</a>
                        </li>
                    
                        <li>
                            <a href="https://www.randstad.in/job-seeker/our-offices/" target="_self">our offices</a>
                        </li>
                    
                        </ul>
                    
            </li>
        
            <li>
                <a href="https://www.randstad.in/employer-brand-research/">employer brand research</a>
                
                        <span class="nav-global-small-toggle has-bg-img">toggle</span>
                        <ul class="list-clean nav-global-small-sub">
                            
                        <li>
                            <a href="https://www.randstad.in/employer-brand-research/about-randstad-award/">About Randstad Award</a>
                        </li>
                    
                        <li>
                            <a href="https://www.randstad.in/employer-brand-research/randstad-award-2018/">Randstad Award 2018</a>
                        </li>
                    
                        <li>
                            <a href="https://www.randstad.in/employer-brand-research/request-for-a-country-report/">Request for a country report</a>
                        </li>
                    
                        <li>
                            <a href="https://www.randstad.in/employer-brand-research/employer-branding/">employer branding</a>
                        </li>
                    
                        </ul>
                    
            </li>
        
            <li>
                <a href="https://www.randstad.in/randstad-insights/">randstad insights</a>
                
                        <span class="nav-global-small-toggle has-bg-img">toggle</span>
                        <ul class="list-clean nav-global-small-sub">
                            
                        <li>
                            <a href="https://www.randstad.in/randstad-insights/workforce-gender-parity-a-4-point-agenda-for-indias-surge/">Workforce Gender Parity - A 4-point Agenda for India’s Surge</a>
                        </li>
                    
                        </ul>
                    
            </li>
        
            <li>
                <a href="https://www.randstad.in/futurist-chro/">futurist chro</a>
                
                        <span class="nav-global-small-toggle has-bg-img">toggle</span>
                        <ul class="list-clean nav-global-small-sub">
                            
                        <li>
                            <a href="https://www.randstad.in/futurist-chro/hr-transformation/">hr transformation</a>
                        </li>
                    
                        <li>
                            <a href="https://www.randstad.in/futurist-chro/managing-millenials/">managing millenials</a>
                        </li>
                    
                        <li>
                            <a href="https://www.randstad.in/futurist-chro/workplace-of-the-future/">workplace of the future</a>
                        </li>
                    
                        <li>
                            <a href="https://www.randstad.in/futurist-chro/hr-and-technology/">hr and technology</a>
                        </li>
                    
                        <li>
                            <a href="https://www.randstad.in/futurist-chro/randstad-five-forces-redefining-the-world-of-hr-e_book.pdf">Randstad - Five Forces Redefining the World of HR - E_book</a>
                        </li>
                    
                        </ul>
                    
            </li>
        
                <li><a href="https://www.randstad.in/contact-us/">contact us</a></li>
                <li><a href="https://www.randstad.in/worldwide/">Randstad worldwide</a></li>
            </ul>
        
</div>





    
<script type="text/javascript">
//<![CDATA[
var Page_ValidationSummaries =  new Array(document.getElementById("ctl08_ctl04_FormValidationSummary"));
var Page_Validators =  new Array(document.getElementById("ctl08_ctl02_UserNameRequired"), document.getElementById("ctl08_ctl02_PasswordRequired"), document.getElementById("ctl08_ctl04_EmailValidator"), document.getElementById("ctl08_ctl04_EmailInvalidValidator"), document.getElementById("ctl08_ctl04_EmailRetypeValidator"), document.getElementById("ctl08_ctl04_EmailCompareValidator"), document.getElementById("ctl08_ctl04_PasswordRequiredValidator"), document.getElementById("ctl08_ctl04_PasswordRequireLengthValidator"), document.getElementById("ctl08_ctl04_PasswordRequireOneDigitValidator"), document.getElementById("ctl08_ctl04_PasswordRequireNonLetterOrDigitValidator"), document.getElementById("ctl08_ctl04_PasswordRequireUpperCaseValidator"), document.getElementById("ctl08_ctl04_PasswordRequireLowerCaseValidator"), document.getElementById("ctl08_ctl04_PasswordRetypeRequiredValidator"), document.getElementById("ctl08_ctl04_PasswordCompareValidator"), document.getElementById("ctl08_ctl04_FirstNameValidator"), document.getElementById("ctl08_ctl04_LastNameValidator"), document.getElementById("ctl08_ctl04_PhoneMobileValidator"), document.getElementById("ctl08_ctl04_PhoneMobileRegexValidator"), document.getElementById("ctl08_ctl04_CityValidator"), document.getElementById("ctl08_ctl04_IndustryValidator"), document.getElementById("ctl08_ctl04_CategoryValidator"), document.getElementById("ctl08_ctl04_EducationalQuafilicationValidator"), document.getElementById("ctl08_ctl04_OverallExperienceValidator"), document.getElementById("ctl08_ctl04_PresentCTCLakhsValidator"), document.getElementById("ctl08_ctl04_PresentCTCThousandsValidator"), document.getElementById("ctl08_ctl04_CVFileUploadValidator"), document.getElementById("ctl08_ctl04_TermsAndConditionsValidator"));
//]]>
</script>

<script type="text/javascript">
//<![CDATA[
var ctl08_ctl02_UserNameRequired = document.all ? document.all["ctl08_ctl02_UserNameRequired"] : document.getElementById("ctl08_ctl02_UserNameRequired");
ctl08_ctl02_UserNameRequired.controltovalidate = "ctl08_ctl02_UserNameTextBox";
ctl08_ctl02_UserNameRequired.errormessage = "Email address (username) is required";
ctl08_ctl02_UserNameRequired.display = "Dynamic";
ctl08_ctl02_UserNameRequired.validationGroup = "SimpleLoginPanel";
ctl08_ctl02_UserNameRequired.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
ctl08_ctl02_UserNameRequired.initialvalue = "";
var ctl08_ctl02_PasswordRequired = document.all ? document.all["ctl08_ctl02_PasswordRequired"] : document.getElementById("ctl08_ctl02_PasswordRequired");
ctl08_ctl02_PasswordRequired.controltovalidate = "ctl08_ctl02_PasswordTextBox";
ctl08_ctl02_PasswordRequired.errormessage = "Password is required";
ctl08_ctl02_PasswordRequired.display = "Dynamic";
ctl08_ctl02_PasswordRequired.validationGroup = "SimpleLoginPanel";
ctl08_ctl02_PasswordRequired.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
ctl08_ctl02_PasswordRequired.initialvalue = "";
var ctl08_ctl04_FormValidationSummary = document.all ? document.all["ctl08_ctl04_FormValidationSummary"] : document.getElementById("ctl08_ctl04_FormValidationSummary");
ctl08_ctl04_FormValidationSummary.validationGroup = "Register";
var ctl08_ctl04_EmailValidator = document.all ? document.all["ctl08_ctl04_EmailValidator"] : document.getElementById("ctl08_ctl04_EmailValidator");
ctl08_ctl04_EmailValidator.controltovalidate = "ctl08_ctl04_EmailTextBox";
ctl08_ctl04_EmailValidator.errormessage = "email is required";
ctl08_ctl04_EmailValidator.display = "Dynamic";
ctl08_ctl04_EmailValidator.validationGroup = "Register";
ctl08_ctl04_EmailValidator.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
ctl08_ctl04_EmailValidator.initialvalue = "";
var ctl08_ctl04_EmailInvalidValidator = document.all ? document.all["ctl08_ctl04_EmailInvalidValidator"] : document.getElementById("ctl08_ctl04_EmailInvalidValidator");
ctl08_ctl04_EmailInvalidValidator.controltovalidate = "ctl08_ctl04_EmailTextBox";
ctl08_ctl04_EmailInvalidValidator.errormessage = "email is invalid";
ctl08_ctl04_EmailInvalidValidator.display = "Dynamic";
ctl08_ctl04_EmailInvalidValidator.validationGroup = "Register";
ctl08_ctl04_EmailInvalidValidator.evaluationfunction = "RegularExpressionValidatorEvaluateIsValid";
ctl08_ctl04_EmailInvalidValidator.validationexpression = "^([a-zA-Z0-9_\\-\\.\\+\\\']+)@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.)|(([a-zA-Z0-9\\-]+\\.)+))([a-zA-Z]{2,24}|[0-9]{1,3})(\\]?)\\s*$";
var ctl08_ctl04_EmailRetypeValidator = document.all ? document.all["ctl08_ctl04_EmailRetypeValidator"] : document.getElementById("ctl08_ctl04_EmailRetypeValidator");
ctl08_ctl04_EmailRetypeValidator.controltovalidate = "ctl08_ctl04_EmailRetypeTextBox";
ctl08_ctl04_EmailRetypeValidator.errormessage = "re-type email is required";
ctl08_ctl04_EmailRetypeValidator.display = "Dynamic";
ctl08_ctl04_EmailRetypeValidator.validationGroup = "Register";
ctl08_ctl04_EmailRetypeValidator.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
ctl08_ctl04_EmailRetypeValidator.initialvalue = "";
var ctl08_ctl04_EmailCompareValidator = document.all ? document.all["ctl08_ctl04_EmailCompareValidator"] : document.getElementById("ctl08_ctl04_EmailCompareValidator");
ctl08_ctl04_EmailCompareValidator.controltovalidate = "ctl08_ctl04_EmailRetypeTextBox";
ctl08_ctl04_EmailCompareValidator.errormessage = "the re-typed email doesn\'t match your first entry";
ctl08_ctl04_EmailCompareValidator.display = "Dynamic";
ctl08_ctl04_EmailCompareValidator.validationGroup = "Register";
ctl08_ctl04_EmailCompareValidator.evaluationfunction = "CompareValidatorEvaluateIsValid";
ctl08_ctl04_EmailCompareValidator.controltocompare = "ctl08_ctl04_EmailTextBox";
ctl08_ctl04_EmailCompareValidator.controlhookup = "ctl08_ctl04_EmailTextBox";
var ctl08_ctl04_PasswordRequiredValidator = document.all ? document.all["ctl08_ctl04_PasswordRequiredValidator"] : document.getElementById("ctl08_ctl04_PasswordRequiredValidator");
ctl08_ctl04_PasswordRequiredValidator.controltovalidate = "ctl08_ctl04_PasswordTextBox";
ctl08_ctl04_PasswordRequiredValidator.errormessage = "password is required";
ctl08_ctl04_PasswordRequiredValidator.display = "Dynamic";
ctl08_ctl04_PasswordRequiredValidator.validationGroup = "Register";
ctl08_ctl04_PasswordRequiredValidator.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
ctl08_ctl04_PasswordRequiredValidator.initialvalue = "";
var ctl08_ctl04_PasswordRequireLengthValidator = document.all ? document.all["ctl08_ctl04_PasswordRequireLengthValidator"] : document.getElementById("ctl08_ctl04_PasswordRequireLengthValidator");
ctl08_ctl04_PasswordRequireLengthValidator.controltovalidate = "ctl08_ctl04_PasswordTextBox";
ctl08_ctl04_PasswordRequireLengthValidator.errormessage = "be at least 6 character long ";
ctl08_ctl04_PasswordRequireLengthValidator.display = "Dynamic";
ctl08_ctl04_PasswordRequireLengthValidator.validationGroup = "Register";
ctl08_ctl04_PasswordRequireLengthValidator.evaluationfunction = "RegularExpressionValidatorEvaluateIsValid";
ctl08_ctl04_PasswordRequireLengthValidator.validationexpression = ".{6,}$";
var ctl08_ctl04_PasswordRequireOneDigitValidator = document.all ? document.all["ctl08_ctl04_PasswordRequireOneDigitValidator"] : document.getElementById("ctl08_ctl04_PasswordRequireOneDigitValidator");
ctl08_ctl04_PasswordRequireOneDigitValidator.controltovalidate = "ctl08_ctl04_PasswordTextBox";
ctl08_ctl04_PasswordRequireOneDigitValidator.errormessage = "including one digit (“09”), ";
ctl08_ctl04_PasswordRequireOneDigitValidator.display = "Dynamic";
ctl08_ctl04_PasswordRequireOneDigitValidator.validationGroup = "Register";
ctl08_ctl04_PasswordRequireOneDigitValidator.evaluationfunction = "RegularExpressionValidatorEvaluateIsValid";
ctl08_ctl04_PasswordRequireOneDigitValidator.validationexpression = "^(?=.*?[0-9]).+$";
var ctl08_ctl04_PasswordRequireNonLetterOrDigitValidator = document.all ? document.all["ctl08_ctl04_PasswordRequireNonLetterOrDigitValidator"] : document.getElementById("ctl08_ctl04_PasswordRequireNonLetterOrDigitValidator");
ctl08_ctl04_PasswordRequireNonLetterOrDigitValidator.controltovalidate = "ctl08_ctl04_PasswordTextBox";
ctl08_ctl04_PasswordRequireNonLetterOrDigitValidator.errormessage = "one non letter character (!@#$%) and ";
ctl08_ctl04_PasswordRequireNonLetterOrDigitValidator.display = "Dynamic";
ctl08_ctl04_PasswordRequireNonLetterOrDigitValidator.validationGroup = "Register";
ctl08_ctl04_PasswordRequireNonLetterOrDigitValidator.evaluationfunction = "RegularExpressionValidatorEvaluateIsValid";
ctl08_ctl04_PasswordRequireNonLetterOrDigitValidator.validationexpression = "^(?=.*[^\\da-zA-Z]).+$";
var ctl08_ctl04_PasswordRequireUpperCaseValidator = document.all ? document.all["ctl08_ctl04_PasswordRequireUpperCaseValidator"] : document.getElementById("ctl08_ctl04_PasswordRequireUpperCaseValidator");
ctl08_ctl04_PasswordRequireUpperCaseValidator.controltovalidate = "ctl08_ctl04_PasswordTextBox";
ctl08_ctl04_PasswordRequireUpperCaseValidator.errormessage = "at least one uppercase (“AZ”) ";
ctl08_ctl04_PasswordRequireUpperCaseValidator.display = "Dynamic";
ctl08_ctl04_PasswordRequireUpperCaseValidator.validationGroup = "Register";
ctl08_ctl04_PasswordRequireUpperCaseValidator.evaluationfunction = "RegularExpressionValidatorEvaluateIsValid";
ctl08_ctl04_PasswordRequireUpperCaseValidator.validationexpression = "^(?=.*[A-Z]).+$";
var ctl08_ctl04_PasswordRequireLowerCaseValidator = document.all ? document.all["ctl08_ctl04_PasswordRequireLowerCaseValidator"] : document.getElementById("ctl08_ctl04_PasswordRequireLowerCaseValidator");
ctl08_ctl04_PasswordRequireLowerCaseValidator.controltovalidate = "ctl08_ctl04_PasswordTextBox";
ctl08_ctl04_PasswordRequireLowerCaseValidator.errormessage = "and lowercase (“az”)";
ctl08_ctl04_PasswordRequireLowerCaseValidator.display = "Dynamic";
ctl08_ctl04_PasswordRequireLowerCaseValidator.validationGroup = "Register";
ctl08_ctl04_PasswordRequireLowerCaseValidator.evaluationfunction = "RegularExpressionValidatorEvaluateIsValid";
ctl08_ctl04_PasswordRequireLowerCaseValidator.validationexpression = "^(?=.*[a-z]).+$";
var ctl08_ctl04_PasswordRetypeRequiredValidator = document.all ? document.all["ctl08_ctl04_PasswordRetypeRequiredValidator"] : document.getElementById("ctl08_ctl04_PasswordRetypeRequiredValidator");
ctl08_ctl04_PasswordRetypeRequiredValidator.controltovalidate = "ctl08_ctl04_PasswordRetypeTextBox";
ctl08_ctl04_PasswordRetypeRequiredValidator.errormessage = "re-type password is required";
ctl08_ctl04_PasswordRetypeRequiredValidator.display = "Dynamic";
ctl08_ctl04_PasswordRetypeRequiredValidator.validationGroup = "Register";
ctl08_ctl04_PasswordRetypeRequiredValidator.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
ctl08_ctl04_PasswordRetypeRequiredValidator.initialvalue = "";
var ctl08_ctl04_PasswordCompareValidator = document.all ? document.all["ctl08_ctl04_PasswordCompareValidator"] : document.getElementById("ctl08_ctl04_PasswordCompareValidator");
ctl08_ctl04_PasswordCompareValidator.controltovalidate = "ctl08_ctl04_PasswordRetypeTextBox";
ctl08_ctl04_PasswordCompareValidator.errormessage = "the re-typed password doesn\'t match your first entry";
ctl08_ctl04_PasswordCompareValidator.display = "Dynamic";
ctl08_ctl04_PasswordCompareValidator.validationGroup = "Register";
ctl08_ctl04_PasswordCompareValidator.evaluationfunction = "CompareValidatorEvaluateIsValid";
ctl08_ctl04_PasswordCompareValidator.controltocompare = "ctl08_ctl04_PasswordTextBox";
ctl08_ctl04_PasswordCompareValidator.controlhookup = "ctl08_ctl04_PasswordTextBox";
var ctl08_ctl04_FirstNameValidator = document.all ? document.all["ctl08_ctl04_FirstNameValidator"] : document.getElementById("ctl08_ctl04_FirstNameValidator");
ctl08_ctl04_FirstNameValidator.controltovalidate = "ctl08_ctl04_FirstNameTextBox";
ctl08_ctl04_FirstNameValidator.errormessage = "first name is required";
ctl08_ctl04_FirstNameValidator.display = "Dynamic";
ctl08_ctl04_FirstNameValidator.validationGroup = "Register";
ctl08_ctl04_FirstNameValidator.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
ctl08_ctl04_FirstNameValidator.initialvalue = "";
var ctl08_ctl04_LastNameValidator = document.all ? document.all["ctl08_ctl04_LastNameValidator"] : document.getElementById("ctl08_ctl04_LastNameValidator");
ctl08_ctl04_LastNameValidator.controltovalidate = "ctl08_ctl04_LastNameTextBox";
ctl08_ctl04_LastNameValidator.errormessage = "last name is required";
ctl08_ctl04_LastNameValidator.display = "Dynamic";
ctl08_ctl04_LastNameValidator.validationGroup = "Register";
ctl08_ctl04_LastNameValidator.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
ctl08_ctl04_LastNameValidator.initialvalue = "";
var ctl08_ctl04_PhoneMobileValidator = document.all ? document.all["ctl08_ctl04_PhoneMobileValidator"] : document.getElementById("ctl08_ctl04_PhoneMobileValidator");
ctl08_ctl04_PhoneMobileValidator.controltovalidate = "ctl08_ctl04_PhoneMobileTextBox";
ctl08_ctl04_PhoneMobileValidator.errormessage = "phone (mobile) is required";
ctl08_ctl04_PhoneMobileValidator.display = "Dynamic";
ctl08_ctl04_PhoneMobileValidator.validationGroup = "Register";
ctl08_ctl04_PhoneMobileValidator.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
ctl08_ctl04_PhoneMobileValidator.initialvalue = "";
var ctl08_ctl04_PhoneMobileRegexValidator = document.all ? document.all["ctl08_ctl04_PhoneMobileRegexValidator"] : document.getElementById("ctl08_ctl04_PhoneMobileRegexValidator");
ctl08_ctl04_PhoneMobileRegexValidator.controltovalidate = "ctl08_ctl04_PhoneMobileTextBox";
ctl08_ctl04_PhoneMobileRegexValidator.errormessage = "phone (mobile) is invalid";
ctl08_ctl04_PhoneMobileRegexValidator.display = "Dynamic";
ctl08_ctl04_PhoneMobileRegexValidator.validationGroup = "Register";
ctl08_ctl04_PhoneMobileRegexValidator.evaluationfunction = "RegularExpressionValidatorEvaluateIsValid";
ctl08_ctl04_PhoneMobileRegexValidator.validationexpression = "^(7|8|9)\\d{9}$";
var ctl08_ctl04_CityValidator = document.all ? document.all["ctl08_ctl04_CityValidator"] : document.getElementById("ctl08_ctl04_CityValidator");
ctl08_ctl04_CityValidator.controltovalidate = "ctl08_ctl04_CityDropDownList";
ctl08_ctl04_CityValidator.errormessage = "city is required";
ctl08_ctl04_CityValidator.display = "Dynamic";
ctl08_ctl04_CityValidator.validationGroup = "Register";
ctl08_ctl04_CityValidator.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
ctl08_ctl04_CityValidator.initialvalue = "-1";
var ctl08_ctl04_IndustryValidator = document.all ? document.all["ctl08_ctl04_IndustryValidator"] : document.getElementById("ctl08_ctl04_IndustryValidator");
ctl08_ctl04_IndustryValidator.controltovalidate = "ctl08_ctl04_IndustryDropDownList";
ctl08_ctl04_IndustryValidator.errormessage = "industry is required";
ctl08_ctl04_IndustryValidator.display = "Dynamic";
ctl08_ctl04_IndustryValidator.validationGroup = "Register";
ctl08_ctl04_IndustryValidator.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
ctl08_ctl04_IndustryValidator.initialvalue = "-1";
var ctl08_ctl04_CategoryValidator = document.all ? document.all["ctl08_ctl04_CategoryValidator"] : document.getElementById("ctl08_ctl04_CategoryValidator");
ctl08_ctl04_CategoryValidator.controltovalidate = "ctl08_ctl04_CategoryDropDownList";
ctl08_ctl04_CategoryValidator.errormessage = "function is required";
ctl08_ctl04_CategoryValidator.display = "Dynamic";
ctl08_ctl04_CategoryValidator.validationGroup = "Register";
ctl08_ctl04_CategoryValidator.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
ctl08_ctl04_CategoryValidator.initialvalue = "-1";
var ctl08_ctl04_EducationalQuafilicationValidator = document.all ? document.all["ctl08_ctl04_EducationalQuafilicationValidator"] : document.getElementById("ctl08_ctl04_EducationalQuafilicationValidator");
ctl08_ctl04_EducationalQuafilicationValidator.controltovalidate = "ctl08_ctl04_QualificationDropDownList";
ctl08_ctl04_EducationalQuafilicationValidator.errormessage = "highest educational qualification is required";
ctl08_ctl04_EducationalQuafilicationValidator.display = "Dynamic";
ctl08_ctl04_EducationalQuafilicationValidator.validationGroup = "Register";
ctl08_ctl04_EducationalQuafilicationValidator.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
ctl08_ctl04_EducationalQuafilicationValidator.initialvalue = "-1";
var ctl08_ctl04_OverallExperienceValidator = document.all ? document.all["ctl08_ctl04_OverallExperienceValidator"] : document.getElementById("ctl08_ctl04_OverallExperienceValidator");
ctl08_ctl04_OverallExperienceValidator.controltovalidate = "ctl08_ctl04_ExperienceInYearsDropDownList";
ctl08_ctl04_OverallExperienceValidator.errormessage = "overall experience is required";
ctl08_ctl04_OverallExperienceValidator.display = "Dynamic";
ctl08_ctl04_OverallExperienceValidator.validationGroup = "Register";
ctl08_ctl04_OverallExperienceValidator.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
ctl08_ctl04_OverallExperienceValidator.initialvalue = "-1";
var ctl08_ctl04_PresentCTCLakhsValidator = document.all ? document.all["ctl08_ctl04_PresentCTCLakhsValidator"] : document.getElementById("ctl08_ctl04_PresentCTCLakhsValidator");
ctl08_ctl04_PresentCTCLakhsValidator.controltovalidate = "ctl08_ctl04_PresentCTCLakhsDropDownList";
ctl08_ctl04_PresentCTCLakhsValidator.errormessage = "lakhs is required";
ctl08_ctl04_PresentCTCLakhsValidator.display = "Dynamic";
ctl08_ctl04_PresentCTCLakhsValidator.validationGroup = "Register";
ctl08_ctl04_PresentCTCLakhsValidator.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
ctl08_ctl04_PresentCTCLakhsValidator.initialvalue = "-1";
var ctl08_ctl04_PresentCTCThousandsValidator = document.all ? document.all["ctl08_ctl04_PresentCTCThousandsValidator"] : document.getElementById("ctl08_ctl04_PresentCTCThousandsValidator");
ctl08_ctl04_PresentCTCThousandsValidator.controltovalidate = " ";
ctl08_ctl04_PresentCTCThousandsValidator.errormessage = "thousands is required";
ctl08_ctl04_PresentCTCThousandsValidator.display = "Dynamic";
ctl08_ctl04_PresentCTCThousandsValidator.validationGroup = "Register";
ctl08_ctl04_PresentCTCThousandsValidator.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
ctl08_ctl04_PresentCTCThousandsValidator.initialvalue = "-1";
var ctl08_ctl04_CVFileUploadValidator = document.all ? document.all["ctl08_ctl04_CVFileUploadValidator"] : document.getElementById("ctl08_ctl04_CVFileUploadValidator");
ctl08_ctl04_CVFileUploadValidator.controltovalidate = "ctl08_ctl04_CVFileUpload";
ctl08_ctl04_CVFileUploadValidator.errormessage = "<span class=\"cms-file-upload-validator-error-message\">CV is required</span>";
ctl08_ctl04_CVFileUploadValidator.display = "Dynamic";
ctl08_ctl04_CVFileUploadValidator.validationGroup = "Register";
ctl08_ctl04_CVFileUploadValidator.evaluationfunction = "CustomValidatorEvaluateIsValid";
ctl08_ctl04_CVFileUploadValidator.clientvalidationfunction = "CmsValidateFileUpload";
ctl08_ctl04_CVFileUploadValidator.validateemptytext = "true";
var ctl08_ctl04_TermsAndConditionsValidator = document.all ? document.all["ctl08_ctl04_TermsAndConditionsValidator"] : document.getElementById("ctl08_ctl04_TermsAndConditionsValidator");
ctl08_ctl04_TermsAndConditionsValidator.errormessage = "terms is required";
ctl08_ctl04_TermsAndConditionsValidator.display = "Dynamic";
ctl08_ctl04_TermsAndConditionsValidator.validationGroup = "Register";
ctl08_ctl04_TermsAndConditionsValidator.evaluationfunction = "CustomValidatorEvaluateIsValid";
//]]>
</script>


<script type="text/javascript">
//<![CDATA[
$("#ctl08_ctl04_CVFileUploadValidator").ValidateFileUpload({"FileUploadElementId":"ctl08_ctl04_CVFileUpload","IsRequired":"True"});function CmsValidateFileUpload(source, args) { if(!args){ args = {IsValid: false}}args.IsValid = $(source).Validate(args);return args.IsValid;};
var Page_ValidationActive = false;
if (typeof(ValidatorOnLoad) == "function") {
    ValidatorOnLoad();
}

function ValidatorOnSubmit() {
    if (Page_ValidationActive) {
        return ValidatorCommonOnSubmit();
    }
    else {
        return true;
    }
}
        
(function(id) {
    var e = document.getElementById(id);
    if (e) {
        e.dispose = function() {
            Array.remove(Page_ValidationSummaries, document.getElementById(id));
        }
        e = null;
    }
})('ctl08_ctl04_FormValidationSummary');
$("#ctl08_ctl04_CVFileUploadValidator").setValidateOptions({"FileUploadElementId":"ctl08_ctl04_CVFileUpload","AllowedExtensions":".doc,.docx,.pdf,.rtf,.txt","IsRequired":"True","MaxFileSize":"3145728","MaxFileUploads":"1","Message":"\u003cspan class=\"cms-file-upload-validator-error-message\"\u003e\u003cspan class=\"cms-file-upload-validator-error-message\"\u003eCV is required\u003c/span\u003e\u003c/span\u003e","ErrorMessageIsRequired":"\u003cspan class=\"cms-file-upload-validator-error-is-required\"\u003eCV is required\u003c/span\u003e","ErrorMessageExtensions":"\u003cspan class=\"cms-file-upload-validator-error-extensions\"\u003eThe file is in an incorrect format or another program is using the file, please select another file or close all programs using the file\u003c/span\u003e","ErrorMessageFileSize":"\u003cspan class=\"cms-file-upload-validator-error-filesize\"\u003eThe file size is too large, please select another file\u003c/span\u003e","ErrorMessageMaxFileUploads":"\u003cspan class=\"cms-file-upload-validator-error-max-files\"\u003eMaximal 1 file allowed.\u003c/span\u003e","clientValidationFunction":"CmsValidateFileUpload","Display":"Dynamic"});
document.getElementById('ctl08_ctl02_UserNameRequired').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ctl08_ctl02_UserNameRequired'));
}
Sys.Application.add_init(function() {
    $create(Sys.Extended.UI.TextBoxWatermarkBehavior, {"ClientStateFieldID":"ctl08_ctl02_UserNameWatermarkExtender_ClientState","WatermarkCssClass":"watermark","WatermarkText":"username","id":"ctl08_ctl02_UserNameWatermarkExtender"}, null, null, $get("ctl08_ctl02_UserNameTextBox"));
});

document.getElementById('ctl08_ctl02_PasswordRequired').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ctl08_ctl02_PasswordRequired'));
}

document.getElementById('ctl08_ctl04_EmailValidator').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ctl08_ctl04_EmailValidator'));
}

document.getElementById('ctl08_ctl04_EmailInvalidValidator').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ctl08_ctl04_EmailInvalidValidator'));
}

document.getElementById('ctl08_ctl04_EmailRetypeValidator').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ctl08_ctl04_EmailRetypeValidator'));
}

document.getElementById('ctl08_ctl04_EmailCompareValidator').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ctl08_ctl04_EmailCompareValidator'));
}

document.getElementById('ctl08_ctl04_PasswordRequiredValidator').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ctl08_ctl04_PasswordRequiredValidator'));
}

document.getElementById('ctl08_ctl04_PasswordRequireLengthValidator').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ctl08_ctl04_PasswordRequireLengthValidator'));
}

document.getElementById('ctl08_ctl04_PasswordRequireOneDigitValidator').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ctl08_ctl04_PasswordRequireOneDigitValidator'));
}

document.getElementById('ctl08_ctl04_PasswordRequireNonLetterOrDigitValidator').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ctl08_ctl04_PasswordRequireNonLetterOrDigitValidator'));
}

document.getElementById('ctl08_ctl04_PasswordRequireUpperCaseValidator').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ctl08_ctl04_PasswordRequireUpperCaseValidator'));
}

document.getElementById('ctl08_ctl04_PasswordRequireLowerCaseValidator').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ctl08_ctl04_PasswordRequireLowerCaseValidator'));
}

document.getElementById('ctl08_ctl04_PasswordRetypeRequiredValidator').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ctl08_ctl04_PasswordRetypeRequiredValidator'));
}

document.getElementById('ctl08_ctl04_PasswordCompareValidator').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ctl08_ctl04_PasswordCompareValidator'));
}

document.getElementById('ctl08_ctl04_FirstNameValidator').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ctl08_ctl04_FirstNameValidator'));
}

document.getElementById('ctl08_ctl04_LastNameValidator').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ctl08_ctl04_LastNameValidator'));
}

document.getElementById('ctl08_ctl04_PhoneMobileValidator').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ctl08_ctl04_PhoneMobileValidator'));
}

document.getElementById('ctl08_ctl04_PhoneMobileRegexValidator').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ctl08_ctl04_PhoneMobileRegexValidator'));
}

document.getElementById('ctl08_ctl04_CityValidator').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ctl08_ctl04_CityValidator'));
}

document.getElementById('ctl08_ctl04_IndustryValidator').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ctl08_ctl04_IndustryValidator'));
}

document.getElementById('ctl08_ctl04_CategoryValidator').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ctl08_ctl04_CategoryValidator'));
}

document.getElementById('ctl08_ctl04_EducationalQuafilicationValidator').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ctl08_ctl04_EducationalQuafilicationValidator'));
}

document.getElementById('ctl08_ctl04_OverallExperienceValidator').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ctl08_ctl04_OverallExperienceValidator'));
}

document.getElementById('ctl08_ctl04_PresentCTCLakhsValidator').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ctl08_ctl04_PresentCTCLakhsValidator'));
}

document.getElementById('ctl08_ctl04_PresentCTCThousandsValidator').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ctl08_ctl04_PresentCTCThousandsValidator'));
}

document.getElementById('ctl08_ctl04_CVFileUploadValidator').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ctl08_ctl04_CVFileUploadValidator'));
}

document.getElementById('ctl08_ctl04_TermsAndConditionsValidator').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ctl08_ctl04_TermsAndConditionsValidator'));
}
//]]>
</script>
</form>
    <script type="text/javascript">
    (function (n) {
        var u = window.location.href;
        var p = u.split("https://www.randstad.in/")[0];
        var t = n.createElement("script"), i;
        t.type = "text/javascript";
        t.async = !0;
        t.src = p + "//dashboard.whoisvisiting.com/who.js";
        i = n.getElementsByTagName("script")[0];
        i.parentNode.insertBefore(t, i)
    })(document);

        var whoparam = whoparam || [];
        whoparam.push(["AcNo", "49a4f5305328407695ca493ff9ff46df"]);
        whoparam.push(["SendHit", ""]
    );
</script>
<!-- Google Code for Remarketing Tag -->
<!--------------------------------------------------
Remarketing tags may not be associated with personally identifiable information or placed on pages related to sensitive categories. See more information and instructions on how to setup the tag on: http://google.com/ads/remarketingsetup
--------------------------------------------------->
<script type="text/javascript">
/* <![CDATA[ */
var google_conversion_id = 882227598;
var google_custom_params = window.google_tag_params;
var google_remarketing_only = true;
/* ]]> */
</script>
<script type="text/javascript" src="../../../www.googleadservices.com/pagead/f.txt">
</script>
<noscript>
<div style="display:inline;">
<img height="1" width="1" style="border-style:none;" alt="" src="http://googleads.g.doubleclick.net/pagead/viewthroughconversion/882227598/?guid=ON&amp;script=0"/>
</div>
</noscript>
</body>

<!-- Mirrored from www.randstad.in/my-randstad/register/ by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 16 May 2019 09:32:41 GMT -->
</html>