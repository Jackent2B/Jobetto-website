

<!DOCTYPE html>
<html lang="en" xmlns="http://www.w3.org/1999/xhtml" class="bit-no-js">

<!-- Mirrored from www.randstad.in/employers/submit-a-job/ by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 16 May 2019 12:23:16 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->
<head><meta charset="utf-8" /><title>
	
</title><meta name="viewport" content="width=device-width, initial-scale=1" /><meta name="msapplication-config" content="none" /><script src="../../c/customs/log/log.js"></script><link href="https://www.randstad.in/App_Themes/HumanForward/css?v=cVaKcQSAHXetgrI4wYSLc6Qxw1_SGTCpo-e3bFFXzao1" rel="stylesheet"/>
<link href="https://www.randstad.in/App_Themes/z_Custom/css?v=0tsipr3D8YXcSyIDmUaliugeA8xTSwzBOnHS_8nO7kI1" rel="stylesheet"/>
<script type="text/javascript" src="https://www.randstad.in/bundles/jquery?v=iDqcwg1pkzK1enRJYGae9RDhjeqY4RCSbFJnHcxhctM1"></script><script src="../../../cdn.optimizely.com/js/10519950310.js"></script><script type="text/javascript">window.dataLayer = window.dataLayer || []; dataLayer.push({"version":"1.0.3","page":{"environment":"DEV","country":"IN","language":"en","type":"employer","virtual_page":"","breadcrumb":[],"breadcrumb_checkout":[],"search_result_amount":0.00,"search_result_distance":0.00,"search_result_page":0.00,"search_result_zip_code":"","search_result_keyword":"","custom":{"ecommerce_indicator":null}},"user":{"employee_number":"","type":"","signup_date":"","login_status":"guest","no_of_applications":0.00,"consent_given":false,"custom":{"account_id":""}},"gtm_ip_address":"196.195.189.90"});</script>
<!--Start of Zopim Live Chat Script-->
<script type="text/javascript">
window.$zopim||(function(d,s){var z=$zopim=function(c){
z._.push(c)},$=z.s=
d.createElement(s),e=d.getElementsByTagName(s)[0];z.set=function(o){z.set.
_.push(o)};z._=[];z.set._=[];$.async=!0;$.setAttribute('charset','utf-8');
$.src='http://v2.zopim.com/?45lVjLmXzsXaDMwOG5l8sKrvS9jzhfDt';z.t=+new Date;$.
type='text/javascript';e.parentNode.insertBefore($,e)})(document,'script');
</script>
<!--End of Zopim Live Chat Script-->
<!-- Facebook Pixel Code -->
<script>
!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
document,'script','../../../connect.facebook.net/en_US/fbevents.js');
fbq('init', '1488290164719280'); // Insert your pixel ID here.
fbq('track', 'PageView');
</script>
<!-- DO NOT MODIFY -->
<!-- End Facebook Pixel Code --><script type="text/javascript">(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src='../../../www.googletagmanager.com/gtm5445.html?id='+i+dl;f.parentNode.insertBefore(j,f);})(window, document, 'script', 'dataLayer', 'GTM-MMD9J43');</script><meta name="description" content="Free jobs posting sites: Randstad India allows you to post your job vacancies online for free and helps you in hiring the right talent at the right time. Our pan India presence ensures that you have access to right talent for all your recruitment needs." /><link rel="canonical" href="index.html" /><link rel="stylesheet" type="text/css" href="body%7bfont-size_16px%3b%7d.html" /><link href="https://www.randstad.in/WebResource.axd?d=hcXDZhXiidgsQUtEo5iT3z8lcRv-y9r6C6UAcSeI6O7W-yC0ltwr66XXumB57aaoscyev4yceV8vv0iattB1i9P1eyG86DoU6p1hK5CdOBl9vSZkb65cZvaxA-Lu_i-1lSmeS37Rt2qagJns34Dzc37UZNRBPRxMnnqxtgZcme41&amp;t=636342377574383830" type="text/css" rel="stylesheet" /></head>
<body id="BodyWrapper">
    
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-MMD9J43" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    
    <form method="post" action="" onsubmit="javascript:return WebForm_OnSubmit();" id="Form1" enctype="multipart/form-data">
<div class="aspNetHidden">
<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="" />
<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="" />
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="e5ebLIRVg2z/Ogmzd3C0Oydv+ansuXJYiS9Q2+4inxc12KdmSDydOLXYKBpXBqgiCzsYhKwBEjt9WilRWb3fNr2xik5nM5ALc1AZEgU+uoVJZI2s/leemhJTlAA9NDyAmXbBdc/L/z0Y9Wo3u7XFdGL6oEi6wasBTw1UlRElQJbMK9PNVc9vSOYF4EpswVaU1WV06thSGnPfHVeWiy+o64VVu7Tk+wp1cS71Df/XGOHMVdmpvR+A96N1lO0d3SSk" />
</div>

<script type="text/javascript">
//<![CDATA[
var theForm = document.forms['Form1'];
if (!theForm) {
    theForm = document.Form1;
}
function __doPostBack(eventTarget, eventArgument) {
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
        theForm.__EVENTTARGET.value = eventTarget;
        theForm.__EVENTARGUMENT.value = eventArgument;
        theForm.submit();
    }
}
//]]>
</script>



<script src="https://www.randstad.in/ScriptResource.axd?d=nv7asgRUU0tRmHNR2D6t1Ad6UINoXrXuEvBLqTieLJwwFgHqGdl8wGwWk_46l7LSUk1h9CK4sfsVpav06Dk2dWtQAb7fONStneZfiLVxUu1Ud8ogkkjDIiQ-ToFkbroxVDrBP9ux3t9t8DU9AcnbzQ2&amp;t=29665526" type="text/javascript"></script>
<script src="https://www.randstad.in/ScriptResource.axd?d=vTFkWNX2eNyb8c5dcEWBOWt8Apko25oS7UwFhloQDUQRq9DLS8p2YTcR4-X52Pkk9rPdhGRhoasMRHMWibf9CxxDAfd0CGxFNu2rcL0cXsEB5SRsqTkgtcK-yJ4nZajDbJbBYOo0GbhHieTY0MhxUcPHv0TTkNbiED1vSk1nd23E6ZM3ubDJd9kP2NuzDR8X5PWS4Hf14_aLXchr13jO3YWNlAhTU5vCNP-0rTbpZPTem7TCad19_wFx5SEZm59JW3cBWDMyCykv4uF9jzCp1SL2_uUGzXTLxvShrtMqc5rm6Hr6ipHuc52ehy4hdY0kRK-DXbvEzL60HwHVgujJ-X7eokfJ2KThLIesi98pZrdiiGsBrkF-83Nu-SC0s5kbBsP9ltMlhcH56U77gxzXlqXZNAGLfJhSEb-RSxVvfwY98oc-uV2Rhv2rKBMXvrjHOK5U3WHwKSDdAU3uOIFY_A2" type="text/javascript"></script>
<script src="https://www.randstad.in/ScriptResource.axd?d=dwY9oWetJoJoVpgL6Zq8OCzj3JL4Sq8mcJWalCFxZXJYBH96U76F7qEgif8QPp37pNgiQ5ydOl4EW_fmRPQBrtk67nGDAdnYfsQ8rgv1OZgYu_W732ILidvnv0nwCAQqjw_vfVrbbwmPI4Q-5oUj_7bc7WuIRvg3bOxpXmHgSow1&amp;t=ffffffff999c3159" type="text/javascript"></script>
<script src="../../c/customs/validation/cmslinkbutton.js" type="text/javascript"></script>
<script src="../../c/s/jquery.loaded.js" type="text/javascript"></script>
<script src="https://www.randstad.in/bundles/general?v=OlROaRAV-WFfBkn0Ew9H4Wpxg6Q5ELlcXKfDEE7a69c1" type="text/javascript"></script>
<script src="../../CustomScripts/Forms/formBranchData.js" type="text/javascript"></script>
<script src="https://www.randstad.in/ScriptResource.axd?d=X6kQKInQS5YQqruiTh57iMCEWEQXetzy8xsPtTFNCw9vSdtPg3Wy-YqbXOL1uEMxpPuh1kmTbcIPPLjAh1W9X6I2qqlbxEZRQpdw5B2VrMBNo2Kvqwca9GTVBZBNzNWE0&amp;t=ffffffff8fe80928" type="text/javascript"></script>
<script type="text/javascript">
//<![CDATA[
function WebForm_OnSubmit() {
null;if (typeof(ValidatorOnSubmit) == "function" && ValidatorOnSubmit() == false) return false;
return true;
}
//]]>
</script>

<div class="aspNetHidden">

	<input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="FCB7707C" />
	<input type="hidden" name="__VIEWSTATEENCRYPTED" id="__VIEWSTATEENCRYPTED" value="" />
</div>
        <script type="text/javascript">
//<![CDATA[
Sys.WebForms.PageRequestManager._initialize('ctl05', 'Form1', [], [], [], 90, '');
//]]>
</script>

        
        




<header class="masthead sb-slide box">
    <div class="masthead-top box-inner">
        
        
        
        
<ul class="list-clean nav-utility">
    <li>
        <label class="float-right nav-handler sb-toggle-right has-bg-img"></label>
    </li>
 <!--   <li class="hide-for-xlarge quick-login-small">
        <a id="ctl09_ctl01_ctl00_MyRandstadHyperLink" class="hide-for-xlarge my-randstad-login-small has-bg-img" href="https://www.randstad.in/my-randstad/">my Randstad</a></li>
    
            
            <li class="has-sep hide-for-small hide-for-medium hide-for-large">
                <a id="ctl09_ctl01_ctl00_NavigationListView_ctrl0_FromFolderHyperLink" href="https://www.randstad.in/contact-us/">contact us</a></li> 
        
        
    <li id="ctl09_ctl01_ctl00_MyRandstadLi" class="hide-for-small hide-for-medium hide-for-large my-randstad-login has-bg-img-before">
        <span id="ctl09_ctl01_ctl00_MyRandstadLabel">my Randstad</span></li> -->
</ul>
 <a href=""><img src="New folder (3)\logo-2.png" alt="Logo">
        <title>submit a job</title></a>
        
<!--
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 205 30.64"><path class="a" d="M15.95,30.32H20.5V18.87a2.26,2.26,0,0,0-.67-1.62l-6.75-6.75a2.25,2.25,0,0,0-1.62-.67H0v4.56H12.53a3.42,3.42,0,0,1,3.42,3.42Z" transform="translate(0 -0.18)"/><path class="a" d="M27.28,30.32H22.72V18.87a2.26,2.26,0,0,1,.67-1.62l6.75-6.75a2.25,2.25,0,0,1,1.62-.67H43.22v4.56H30.69a3.42,3.42,0,0,0-3.42,3.42Z" transform="translate(0 -0.18)"/><path class="a" d="M63.8,9.82h3.52V13h.08a6.24,6.24,0,0,1,5.34-3.66,10.69,10.69,0,0,1,2.49.28V13a5.6,5.6,0,0,0-2.09-.36c-3.38,0-5.59,3.22-5.59,8.37v9.33H63.8Z" transform="translate(0 -0.18)"/><path class="a" d="M179.24,22.35c0,3.09-2,5.44-5.7,5.44-1.72,0-3.81-1.18-3.81-3.36,0-3.65,5.06-4,7.1-4,.8,0,1.6.08,2.41.08Zm-11-7.87a9.52,9.52,0,0,1,5.94-2.13c3.77,0,5.05,1.84,5.05,5.38-1.48-.08-2.53-.08-4-.08-3.89,0-9.52,1.6-9.52,6.75,0,4.5,3.1,6.42,7.51,6.42a7.6,7.6,0,0,0,6.34-3.11h.08v2.61H183V17.79c0-5.6-2.36-8.47-8.21-8.47A13.1,13.1,0,0,0,168,11.24Z" transform="translate(0 -0.18)"/><path class="a" d="M88,22.35c0,3.09-2,5.44-5.7,5.44-1.73,0-3.81-1.18-3.81-3.36,0-3.65,5.06-4,7.1-4,.8,0,1.6.08,2.41.08ZM77,14.48A9.52,9.52,0,0,1,83,12.35c3.77,0,5.06,1.84,5.06,5.38-1.48-.08-2.53-.08-4-.08-3.89,0-9.52,1.6-9.52,6.75,0,4.5,3.1,6.42,7.51,6.42a7.6,7.6,0,0,0,6.34-3.11h.08v2.61H91.8V17.79c0-5.6-2.36-8.47-8.21-8.47a13.1,13.1,0,0,0-6.74,1.92Z" transform="translate(0 -0.18)"/><path class="a" d="M94.88,9.82h3.64V13h.08a7.39,7.39,0,0,1,6.73-3.72c5.31,0,7.66,3.28,7.66,8.79V30.32h-3.76V19.69c0-4.79-1-7.13-4.35-7.33-4.31,0-6.24,3.47-6.24,8.48v9.48H94.88Z" transform="translate(0 -0.18)"/><path class="a" d="M137.55,26.33a10.06,10.06,0,0,0,4.7,1.45c1.72,0,3.85-.73,3.85-2.95,0-3.76-8.87-3.43-8.87-9.21,0-4.27,3.18-6.31,7.23-6.31a15.49,15.49,0,0,1,4.7.81l-.32,3.27a11,11,0,0,0-4-1.05c-1.92,0-3.61.81-3.61,2.51,0,4.2,8.87,3,8.87,9.58,0,4.39-3.5,6.39-7.15,6.39a11.84,11.84,0,0,1-5.62-1.12Z" transform="translate(0 -0.18)"/><path class="a" d="M164.48,12.85h-5.43V24.11c0,2.38,1.45,3.67,3.17,3.67a4.65,4.65,0,0,0,2.57-.73v3.2a11.94,11.94,0,0,1-3.21.56c-3.89,0-6.29-1.83-6.29-5.94v-12h-4.62v-3h4.62V5.08l3.76-1.2V9.82h5.43Z" transform="translate(0 -0.18)"/><path class="a" d="M189.56,20c-.08-3.76,1.53-7.64,5.62-7.64s6.06,3.92,6.06,7.76c0,3.43-1.77,7.68-6,7.68C191.17,27.79,189.48,23.22,189.56,20ZM201.4,30.32H205V.18h-3.76V12.6h-.08C200,10.72,198,9.32,194.38,9.32c-5.94,0-8.84,4.85-8.84,10.37s2.61,11.13,8.8,11.13a8.22,8.22,0,0,0,7-3.36h.08Z" transform="translate(0 -0.18)"/><path class="a" d="M119.57,20c-.08-3.76,1.53-7.64,5.62-7.64s6.06,3.92,6.06,7.76c0,3.43-1.77,7.68-6,7.68C121.17,27.79,119.48,23.22,119.57,20Zm11.84,10.33H135V.18h-3.76V12.6h-.08C130,10.72,128,9.32,124.38,9.32c-5.94,0-8.84,4.85-8.84,10.37s2.61,11.13,8.8,11.13a8.22,8.22,0,0,0,7-3.36h.08Z" transform="translate(0 -0.18)"/></svg>
        </a>
-->
      <!--  <div class="nav-main2">
            
                    <ul class="cf list-clean hide-for-small hide-for-medium hide-for-large">
                        
                    <li id="ctl09_ctl01_MenuListView_ctrl0_ItemLI">
                        <a id="ctl09_ctl01_MenuListView_ctrl0_ItemHyperLink" href="https://www.randstad.in/job-seeker/">job seeker</a></li>
                
                    <li id="ctl09_ctl01_MenuListView_ctrl1_ItemLI" class="selected">
                        <a id="ctl09_ctl01_MenuListView_ctrl1_ItemHyperLink" href="https://www.randstad.in/employers/">employers</a></li>
                
                    <li id="ctl09_ctl01_MenuListView_ctrl2_ItemLI">
                        <a id="ctl09_ctl01_MenuListView_ctrl2_ItemHyperLink" href="https://www.randstad.in/about-us/">about us</a></li>
                
                    <li id="ctl09_ctl01_MenuListView_ctrl3_ItemLI">
                        <a id="ctl09_ctl01_MenuListView_ctrl3_ItemHyperLink" href="https://www.randstad.in/join-our-team/">join our team</a></li>
                
                    <li id="ctl09_ctl01_MenuListView_ctrl4_ItemLI">
                        <a id="ctl09_ctl01_MenuListView_ctrl4_ItemHyperLink" href="https://www.randstad.in/workforce360/">workforce360</a></li>
                
                    
                
                    <li id="ctl09_ctl01_MenuListView_ctrl6_ItemLI">
                        <a id="ctl09_ctl01_MenuListView_ctrl6_ItemHyperLink" href="https://www.randstad.in/employer-brand-research/">employer brand research</a></li>
                
                    <li id="ctl09_ctl01_MenuListView_ctrl7_ItemLI">
                        <a id="ctl09_ctl01_MenuListView_ctrl7_ItemHyperLink" href="https://www.randstad.in/randstad-insights/">randstad insights</a></li>
                
                    <li id="ctl09_ctl01_MenuListView_ctrl8_ItemLI">
                        <a id="ctl09_ctl01_MenuListView_ctrl8_ItemHyperLink" href="https://www.randstad.in/futurist-chro/">futurist chro</a></li>
                
                    </ul>
                
        </div> -->
    </div> 
    
    <nav class="nav-menu-bar">
     <!--   <div class="nav-menu-bar-inner box-inner">
            <div class="nav-menu-squares">
                
                        <ul class="list-clean">
                            
                        <li>
                            <a id="ctl09_ctl01_SubMenuListView_ctrl0_ItemHyperLink" class="active" href="index.html">submit a job</a></li>
                    
                        <li>
                            <a id="ctl09_ctl01_SubMenuListView_ctrl1_ItemHyperLink" href="https://www.randstad.in/employers/request-a-call-back/">request a call back</a></li>
                    
                        <li>
                            <a id="ctl09_ctl01_SubMenuListView_ctrl2_ItemHyperLink" href="https://www.randstad.in/employers/areas-of-expertise/">areas of expertise</a></li>
                    
                        <li>
                            <a id="ctl09_ctl01_SubMenuListView_ctrl3_ItemHyperLink" href="https://www.randstad.in/employers/our-offices/">our offices</a></li>
                    
                        <li>
                            <a id="ctl09_ctl01_SubMenuListView_ctrl4_ItemHyperLink" href="https://www.randstad.in/employers/randstad-insights/">randstad insights</a></li>
                    
                        </ul>
                    
            </div>
        </div> -->
    </nav>
</header>




<script type="text/javascript">
    $(document).ready(function () {
        renderQuickLogin();
    });
</script>
<div id="ctl09_ctl02_PanelWrapper" class="my-randstad-login-panel" onkeypress="javascript:return WebForm_FireDefaultButton(event, &#39;ctl09_ctl02_LoginButton&#39;)">
	

    <div id="ctl09_ctl02_LogInWrapper" class="my-randstad-login-panel--inner">
        <span id="ctl09_ctl02_TitleLabel" class="quick-login--header">login to my Randstad</span>
        <span id="FailureTextLabel" class="field-error"></span>
        <ol class="list-clean">
            <li class="my-randstad-login-panel-field">
                <label for="ctl09_ctl02_UserNameTextBox" id="ctl09_ctl02_UserNameLabel">Email address (username)</label>
                <input name="ctl09$ctl02$UserNameTextBox" type="text" id="ctl09_ctl02_UserNameTextBox" />
                <span id="ctl09_ctl02_UserNameRequired" title="Email address (username) is required" class="field-error" style="display:none;">Email address (username) is required</span>
                <input type="hidden" name="ctl09$ctl02$UserNameWatermarkExtender_ClientState" id="ctl09_ctl02_UserNameWatermarkExtender_ClientState" />
            </li>
            <li class="my-randstad-login-panel-field">
                <label for="ctl09_ctl02_PasswordTextBox" id="ctl09_ctl02_PasswordLabel">Password</label>
                <input name="ctl09$ctl02$PasswordTextBox" type="password" id="ctl09_ctl02_PasswordTextBox" Placeholder="password" />
                <span id="ctl09_ctl02_PasswordRequired" title="Password is required" class="field-error" style="display:none;">Password is required</span>
            </li>
            <li class="quick-login--forgot-password">
                <a id="ctl09_ctl02_ForgotPasswordHyperLink" class="has-bg-img-after quick-login-more" href="https://www.randstad.in/my-randstad/forgot-password/">I forgot my password</a></li>
            <li class="quick-login--btn">
                <a id="ctl09_ctl02_LoginButton" class="btn btn-prim btn-full" href="javascript:WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;ctl09$ctl02$LoginButton&quot;, &quot;&quot;, true, &quot;SimpleLoginPanel&quot;, &quot;&quot;, false, true))">login</a>
            </li>
            <li class="quick-login--register">
                <a id="ctl09_ctl02_RegisterHyperLink" class="has-bg-img-after quick-login-more" href="https://www.randstad.in/my-randstad/register/">register for a free account</a></li>
        </ol>
    </div>
    

</div>




<div class="box-inner breadcrumb-languages">
    <nav id="ctl09_ctl03_BreadCrumbNav" class="breadcrumb sb-slide hide-for-small">
        <a href="https://www.randstad.in/">home</a><span> / </span><a href="https://www.randstad.in/employers/">employers</a><span> / </span><span>submit a job</span>
    </nav>
    <script type="application/ld+json">{"@context":"http:\/\/schema.org","@type":"BreadcrumbList","itemListElement":[{"@type":"ListItem","item":{"@id":"\/","name":"home"},"position":1},{"@type":"ListItem","item":{"@id":"\/employers\/","name":"employers"},"position":2},{"@type":"ListItem","item":{"@id":null,"name":"submit a job"},"position":3}]}</script>
</div>




<div id="sb-site">
        
    <div id="ctl09_ContentWrapper" class="main">
        <noscript class="no-script-box">
            <div class="box-inner">
                <span id="ctl09_NoScriptTitleLabel" class="no-script-box-header">Warning: Javascript disabled</span>
                <p>
                    Note: our system indicates that Javascript is disabled or not supported by your browser. In order to take advantage of full functionality of this site, javascript must be enabled. Please change your browser options.
                </p>
            </div> 
        </noscript>
        
        
        

        <div id="ctl09_OneColumnDiv" class="box-content cf">
            
            <a id="skipnav"></a>
            <div id="ctl09_OneColumnInnerDiv">
                


<div class="grid-col-1-1">
<div class="snippet snp-page-header snp-bg-opt4">
<!--<div class="box-inner snp-page-header-text">
<h1><span>we help you hire right talent</span>
<span>at the right time.</span></h1>
<div><p>Our pan India presence ensures that you have access to right talent for all your recruitment needs. Need to talk to our experts right away? Call us on our toll free number at&nbsp;<strong>1800-267-4050</strong></p></div>

</div> -->
</div><div class="snippet snp-dynamic-module submit-a-request snp-form">
<div>


<div id="ctl09_ctl04_ctl01_SubmitWrapper" class="box-inner">
    <div class="form-wrapper">
        <h2>
            submit a job</h2>
        <div id="ctl09_ctl04_ctl01_ClientRequestCallback" onkeypress="javascript:return WebForm_FireDefaultButton(event, &#39;ctl09_ctl04_ctl01_SubmitButton&#39;)">
	
            
            <div id="ctl09_ctl04_ctl01_FormValidationSummary" class="nfc-negative form-errors has-bg-img-before" style="display:none;">

	</div>
            <div class="cf form-general">
                <ol class="list-clean form">
                    <li>
                        <span id="ctl09_ctl04_ctl01_RequiredFieldsLabel">Fields marked with * are required fields</span>
                    </li>
                    <li>
                        <h3>
                            contact information</h3>
                    </li>
                    <li class="form-field">
                        <label for="ctl09_ctl04_ctl01_FirstNameTextBox" id="ctl09_ctl04_ctl01_FirstNameLabel" class="is-required">first name</label>
                        <div class="form-element">
                            <input name="ctl09$ctl04$ctl01$FirstNameTextBox" type="text" maxlength="100" id="ctl09_ctl04_ctl01_FirstNameTextBox" title="first name" />
                            
                        </div>
                    </li>
                    <li class="form-field">
                        <label for="ctl09_ctl04_ctl01_LastNameTextBox" id="ctl09_ctl04_ctl01_LastNameLabel" class="is-required">last name</label>
                        <div class="form-element">
                            <input name="ctl09$ctl04$ctl01$LastNameTextBox" type="text" maxlength="100" id="ctl09_ctl04_ctl01_LastNameTextBox" title="last name" />
                            
                        </div>
                    </li>
                    <li class="form-field">
                        <label for="ctl09_ctl04_ctl01_EmailTextBox" id="ctl09_ctl04_ctl01_EmailLabel" class="is-required">e-mail</label>
                        <div class="form-element">
                            <input name="ctl09$ctl04$ctl01$EmailTextBox" type="text" maxlength="250" id="ctl09_ctl04_ctl01_EmailTextBox" title="e-mail" />
                            
                            
                        </div>
                    </li>
                    <li class="form-field">
                        <label for="ctl09_ctl04_ctl01_PhoneTextBox" id="ctl09_ctl04_ctl01_PhoneLabel" class="is-required">phone</label>
                        <div class="form-element">
                            <input name="ctl09$ctl04$ctl01$PhoneTextBox" type="text" maxlength="50" id="ctl09_ctl04_ctl01_PhoneTextBox" title="phone" />
                            
                        </div>
                    </li>
                    <li class="form-field">
                        <label for="ctl09_ctl04_ctl01_DesignationTextBox" id="ctl09_ctl04_ctl01_DesignationLabel" class="is-required">designation</label>
                        <div class="form-element">
                            <input name="ctl09$ctl04$ctl01$DesignationTextBox" type="text" maxlength="150" id="ctl09_ctl04_ctl01_DesignationTextBox" title="designation" />
                            
                        </div>
                    </li>
                    <li class="form-field">
                        <label for="ctl09_ctl04_ctl01_CompanyTextBox" id="ctl09_ctl04_ctl01_CompanyLabel" class="is-required">company</label>
                        <div class="form-element">
                            <input name="ctl09$ctl04$ctl01$CompanyTextBox" type="text" maxlength="150" id="ctl09_ctl04_ctl01_CompanyTextBox" title="company" />
                            
                        </div>
                    </li>
               <!--     <li class="form-field">
                        <label for="ctl09_ctl04_ctl01_LocationDropDownList" id="ctl09_ctl04_ctl01_LocationLabel" class="is-required">your nearest branch</label>
                        <div class="form-element">
                            <select name="ctl09$ctl04$ctl01$LocationDropDownList" id="ctl09_ctl04_ctl01_LocationDropDownList" title="your nearest branch">
		<option value="-1">-- please select --</option>
		<option value="37">Ahmedabad</option>
		<option value="38">Baroda</option>
		<option value="30">Bengaluru</option>
		<option value="27">Bhubaneswar</option>
		<option value="6">Chandigarh</option>
		<option value="29">Chennai</option>
		<option value="28">Cochin</option>
		<option value="24">Coimbatore</option>
		<option value="35">Gurgaon</option>
		<option value="21">Guwahati</option>
		<option value="9">Hubli</option>
		<option value="31">Hyderabad</option>
		<option value="26">Indore</option>
		<option value="20">Jaipur</option>
		<option value="5">Jamshedpur</option>
		<option value="36">Kolkata</option>
		<option value="15">Lucknow</option>
		<option value="7">Madurai</option>
		<option value="11">Mangalore</option>
		<option value="32">Mumbai</option>
		<option value="8">Nagpur</option>
		<option value="34">New Delhi</option>
		<option value="12">Patna</option>
		<option value="33">Pune</option>
		<option value="23">Rajkot</option>
		<option value="22">Surat</option>
		<option value="10">Trivandrum</option>
		<option value="16">Visakapatnam</option>

	</select>
                            
                        </div>
                    </li> -->
             <!--       <li class="form-field">
                        <label for="ctl09_ctl04_ctl01_ServiceDropDownList" id="ctl09_ctl04_ctl01_ServiceLabel" class="is-required">need your service in</label>
                        <div class="form-element">
                            <select name="ctl09$ctl04$ctl01$ServiceDropDownList" id="ctl09_ctl04_ctl01_ServiceDropDownList" title="need your service in">
		<option value="-1">-- please select --</option>
		<option value="Contract Staffing">Contract Staffing</option>
		<option value="Permanent Recruitment">Permanent Recruitment</option>
		<option value="RPO">RPO</option>
		<option value="IT Contract Staffing">IT Contract Staffing</option>

	</select>
                            
                        </div>
                    </li> -->
            <!--        <li class="form-field">
                        <label for="ctl09_ctl04_ctl01_EmailAlertsCheckBox" id="ctl09_ctl04_ctl01_EmailAlertsLabel">e-mail alerts</label>
                        <div class="form-element">
                            <span class="receive-mail-job-check-box" title="e-mail alerts"><input id="ctl09_ctl04_ctl01_EmailAlertsCheckBox" type="checkbox" name="ctl09$ctl04$ctl01$EmailAlertsCheckBox" checked="checked" /><label for="ctl09_ctl04_ctl01_EmailAlertsCheckBox">I would like to receive white papers and event invite related emails from Randstad India</label></span>
                        </div>
                    </li> -->
                    <li>
                        <h3>
                            job information</h3>
                    </li>
                    <li class="form-field">
                        <label for="ctl09_ctl04_ctl01_JobTitleTextBox" id="ctl09_ctl04_ctl01_JobTitleLabel" class="is-required">job title</label>
                        <div class="form-element">
                            <input name="ctl09$ctl04$ctl01$JobTitleTextBox" type="text" maxlength="50" id="ctl09_ctl04_ctl01_JobTitleTextBox" title="job title" /><br />
                            
                        </div>
                    </li>
       <!--             <li class="form-field">
                        <label for="ctl09_ctl04_ctl01_SectorDropDownList" id="ctl09_ctl04_ctl01_SectorLabel" class="is-required">sector</label>
                        <div class="form-element">
                            <select name="ctl09$ctl04$ctl01$SectorDropDownList" id="ctl09_ctl04_ctl01_SectorDropDownList">
		<option value="-1">-- please select --</option>
		<option value="1214">Agro &amp; Seeds</option>
		<option value="1215">Banking &amp; finance</option>
		<option value="1217">General Administration</option>
		<option value="1218">Human Resources</option>
		<option value="1220">Information Technology</option>
		<option value="1221">Insurance</option>
		<option value="1222">ITeS &amp; BPO</option>
		<option value="1224">Legal, Regulatory &amp; Intellectual Property</option>
		<option value="1225">Digital, Marketing &amp; Communication</option>
		<option value="1226">Other</option>
		<option value="1227">Pharma, healthcare &amp; lifesciences</option>
		<option value="1228">Manufacturing</option>
		<option value="1231">Supply Chain &amp; Logistics</option>
		<option value="1232">Construction &amp; Property</option>
		<option value="1233">Sales</option>
		<option value="1235">Employment &amp; Recruitment agency</option>
		<option value="1764">FMCG</option>
		<option value="1765">Consumer durables &amp; electronics</option>
		<option value="1766">Retail</option>
		<option value="1767">Oil, Gas, Power &amp; Energy</option>
		<option value="1768">Telecom</option>
		<option value="1769">Media &amp; entertainment</option>
		<option value="1770">Education</option>
		<option value="1771">Hospitality &amp; Tourism </option>
		<option value="1773">Consulting &amp; VC</option>

	</select> 
                            
                        </div>
                    </li> -->
                    <li class="form-field">
                        <label for="ctl09_ctl04_ctl01_JobSpecificationTextBox" id="ctl09_ctl04_ctl01_JobSpecificationLabel" class="is-required">job specification</label>
                        <div class="form-element">
                            <textarea name="ctl09$ctl04$ctl01$JobSpecificationTextBox" rows="6" cols="20" id="ctl09_ctl04_ctl01_JobSpecificationTextBox" title="job specification">
</textarea><br />
                            
                        </div>
                    </li>
                </ol>
                <div class="cf form-submit">
                    <span id="ctl09_ctl04_ctl01_CmsFormValidator" style="display:none;"></span>
                    <a id="ctl09_ctl04_ctl01_SubmitButton" title="submit" class="btn btn-prim float-right" data-bit-linkbutton="enabled" href="javascript:WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;ctl09$ctl04$ctl01$SubmitButton&quot;, &quot;&quot;, true, &quot;ClientSubmitRequest&quot;, &quot;&quot;, false, true))">submit</a>
                </div>

            </div>
        
</div>
    </div>
</div>

</div>
</div>
</div>
                
                
                
                
                
                
                
                
                
                
                
            </div>
        </div>
        
        
        
        

<div>
    <footer class="cf footer-main">
        <div class="box-inner">
            
            <div id="ctl09_ctl05_FooterDiv" class="grid-wrap">
                        
                        
	<!--                                <div class="footer-main-col">
                                    <div class="footer-main-col-inner">
                                        
                                <div class="footer-link-list">
                                    <div>
                                        <span class="footer-list-header footer-list-header-toggle has-bg-img-after">
                                            job seeker
                                        </span>
                                        
                                                <ul class="list-clean footer-link-list-sub">
                                                    
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/" target="_self">find a job</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/my-randstad/register/" target="_self">submit your cv</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/job-seeker/areas-of-expertise/" target="_self">areas of expertise</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/job-seeker/career-hub/" target="_self">career hub</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/job-seeker/our-offices/" target="_self">our offices</a>
                                                </li>
                                            
                                                </ul>
                                            
                                    </div>
                                    
                                </div> -->
                            
                                <div class="footer-link-list">
                               <!--     <div>
                                        <span class="footer-list-header footer-list-header-toggle has-bg-img-after">
                                            jobs by industry / function
                                        </span>
                                        
                                                <ul class="list-clean footer-link-list-sub">
                                                    
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/s-agro-seeds/" target="_self">jobs in agro and seeds</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/s-construction-property/" target="_self">jobs in construction & property</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/s-consumer-durables-electronics/" target="_self">jobs in consumer durables and electronics</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/s-education/" target="_self">jobs in education</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/s-fmcg/" target="_self">jobs in fmcg</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/s-banking-finance/" target="_self">jobs in banking & finance</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/s-oil-gas-power-energy/" target="_self">jobs in oil, gas, power & energy</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/q-hr/" target="_self">jobs in HR</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/s-information-technology/" target="_self">jobs in IT</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/s-consulting-vc/" target="_self">jobs in consulting & vc</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/s-other/" target="_self">jobs in other</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/s-ites-bpo/" target="_self">jobs in ITeS and BPO</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/s-legal-regulatory-intellectual-property/" target="_self">jobs in legal & intellectual property</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/s-manufacturing/" target="_self">jobs in manufacturing and industrial</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/s-digital-marketing-communication/" target="_self">jobs in digital marketing and communication</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/s-pharma-healthcare-lifesciences/" target="_self">jobs in pharma and healthcare</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/s-retail/" target="_self">jobs in retail</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/q-sales/" target="_self">jobs in sales</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/s-telecom/" target="_self">jobs in telecom</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/s-supply-chain-logistics/" target="_self">jobs in supply chain and logistics</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/job-seeker/jobs-by-industry-city/" target="_self">jobs by Industry / city</a>
                                                </li>
                                            
                                                </ul>
                                            
                                    </div>
                                    
                                </div> 
                            
                                    </div> 
                                </div> 
                            
                    
                        
                                <div class="footer-main-col">
                                    <div class="footer-main-col-inner">
                                        
                                <div class="footer-link-list">
                                    <div>
                                        <span class="footer-list-header footer-list-header-toggle has-bg-img-after">
                                            jobs by location
                                        </span>
                                        
                                                <ul class="list-clean footer-link-list-sub">
                                                    
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/gujarat/ahmedabad/" target="_self">jobs in Ahmedabad</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/karnataka/bengaluru/" target="_self">jobs in Bangalore</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/tamil-nadu/coimbatore/" target="_self">jobs in Coimbatore</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/rajasthan/jaipur/" target="_self">jobs in Jaipur</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/maharashtra/mumbai/" target="_self">jobs in Mumbai</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/gujarat/vadodara/" target="_self">jobs in Vadodara</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/haryana/gurgaon/" target="_self">jobs in Gurgaon</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/jharkhand/jamshedpur/" target="_self">jobs in Jamshedpur</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/bihar/patna/" target="_self">jobs in Patna</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/tamil-nadu/chennai/" target="_self">jobs in Chennai</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/orissa/bhubaneswar/" target="_self">jobs in Bhubaneswar</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/telangana/hyderabad/" target="_self">jobs in Hyderabad</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/assam/guwahati/" target="_self">jobs in Guwahati</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/tamil-nadu/vellore/" target="_self">jobs in Vellore</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/west-bengal/kolkata/" target="_self">jobs in Kolkata</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/maharashtra/nagpur/" target="_self">jobs in Nagpur</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/maharashtra/pune/" target="_self">jobs in Pune</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/uttar-pradesh/kanpur/" target="_self">jobs in Kanpur</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/chandigarh/" target="_self">jobs in Chandigarh</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/madhya-pradesh/indore/" target="_self">jobs in Indore</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/gujarat/bharuch/" target="_self">jobs in Bharuch</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/karnataka/hubli/" target="_self">jobs in Hubli</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/uttar-pradesh/lucknow/" target="_self">jobs in Lucknow</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/new-delhi/" target="_self">jobs in Delhi</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/gujarat/rajkot/" target="_self">jobs in Rajkot</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/andhra-pradesh/visakhapatnam/" target="_self">jobs in Visakhapatnam</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/gujarat/surat/" target="_self">jobs in Surat</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/jobs/andhra-pradesh/vijayawada/" target="_self">jobs in Vijayawada</a>
                                                </li>
                                            
                                                </ul>
                                            
                                    </div>
                                    
                                </div>
                            
                                    </div>
                                </div>
                            
                    
                        
                                <div class="footer-main-col">
                                    <div class="footer-main-col-inner">
                                        
                                <div class="footer-link-list">
                                    <div>
                                        <span class="footer-list-header footer-list-header-toggle has-bg-img-after">
                                            employers
                                        </span>
                                        
                                                <ul class="list-clean footer-link-list-sub">
                                                    
                                                <li>
                                                    <a href="index.html" target="_self">submit a job</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/employers/request-a-call-back/" target="_self">request a call back</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/employers/areas-of-expertise/" target="_self">areas of expertise</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/employers/our-solutions/" target="_self">our solutions</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/employers/our-offices/" target="_self">our offices</a>
                                                </li>
                                            
                                                </ul>
                                            
                                    </div>
                                    
                                </div>
                            
                                <div class="footer-link-list">
                                    <div>
                                        <span class="footer-list-header footer-list-header-toggle has-bg-img-after">
                                            our solutions
                                        </span>
                                        
                                                <ul class="list-clean footer-link-list-sub">
                                                    
                                                <li>
                                                    <a href="https://www.randstad.in/employers/our-solutions/permanent-recruitment/" target="_self">permanent recruitment</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/employers/our-solutions/recruitment-process-outsourcing/" target="_self">recruitment process outsourcing</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/employers/our-solutions/general-staffing/" target="_self">general staffing</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/employers/our-solutions/specialty-staffing/" target="_self">specialty staffing</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/employers/our-solutions/executive-search/" target="_self">executive search</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/employers/our-solutions/headhunters/" target="_self">headhunting</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/employers/our-solutions/manpower-consultancy/" target="_self">manpower consultancy</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/employers/our-solutions/talent-acquisition-and-management-specialist/" target="_self">talent acquisition</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/employers/our-solutions/payroll-services/" target="_self">payroll transfer services</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/employers/our-solutions/sales-and-trade-marketing/" target="_self">sales and trade marketing</a>
                                                </li>
                                            
                                                </ul>
                                            
                                    </div>
                                    
                                </div>
                            
                                <div class="footer-link-list">
                                    <div>
                                        <span class="footer-list-header footer-list-header-toggle has-bg-img-after">
                                            areas of expertise
                                        </span>
                                        
                                                <ul class="list-clean footer-link-list-sub">
                                                    
                                                <li>
                                                    <a href="https://www.randstad.in/employers/areas-of-expertise/analytics-and-data-sciences/" target="_self">analytics and data sciences</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/employers/areas-of-expertise/banking-and-financial-services/" target="_self">banking and financial services</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/employers/areas-of-expertise/civil-and-architecture/" target="_self">civil and architecture</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/employers/areas-of-expertise/operations-logistics-and-supply-chain/" target="_self">operations logistics and supply chain</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/employers/areas-of-expertise/product-management-and-information-technology/" target="_self">product management and information technology</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/employers/areas-of-expertise/sales-and-account-management/" target="_self">sales and account management</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/employers/areas-of-expertise/pharma-life-sciences-healthcare/" target="_self">pharma and healthcare</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/employers/areas-of-expertise/support-functions/" target="_self">support functions</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/employers/areas-of-expertise/hr-recruitment/" target="_self">human resource</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/employers/areas-of-expertise/construction-recruitment/" target="_self">construction recruitment</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/employers/areas-of-expertise/manufacturing-staffing/" target="_self">manufacturing staffing</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/employers/areas-of-expertise/fmcg-recruitment/" target="_self">fmcg recruitment</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/employers/areas-of-expertise/bpo-recruitment/" target="_self">bpo recruitment</a>
                                                </li>
                                            
                                                </ul>
                                            
                                    </div>
                                    
                                </div>
                            
                                    </div>
                                </div>
                            
                    
                        
                                <div class="footer-main-col">
                                    <div class="footer-main-col-inner">
                                        
                                <div class="footer-link-list">
                                    <div>
                                        <span class="footer-list-header footer-list-header-toggle has-bg-img-after">
                                            about us
                                        </span>
                                        
                                                <ul class="list-clean footer-link-list-sub">
                                                    
                                                <li>
                                                    <a href="https://www.randstad.in/about-us/our-history/" target="_self">our history</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/about-us/our-sponsorships/" target="_self">our sponsorships</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/about-us/social-responsibility/" target="_self">social responsibility</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/about-us/press-releases/" target="_self">press releases</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/about-us/randstad-in-the-news/" target="_self">Randstad in the news</a>
                                                </li>
                                            
                                                </ul>
                                            
                                    </div>
                                    
                                </div>
                            
                                <div class="footer-link-list">
                                    <div>
                                        <span class="footer-list-header footer-list-header-toggle has-bg-img-after">
                                            career hub
                                        </span>
                                        
                                                <ul class="list-clean footer-link-list-sub">
                                                    
                                                <li>
                                                    <a href="https://www.randstad.in/job-seeker/career-hub/archives/" target="_self">archives</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/job-seeker/career-hub/archives/?th=93" target="_self">building your career</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/job-seeker/career-hub/archives/?th=94" target="_self">cv and interview advice</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/job-seeker/career-hub/archives/?th=95" target="_self">finding the right job</a>
                                                </li>
                                            
                                                </ul>
                                            
                                    </div>
                                    
                                </div>
                            
                                <div class="footer-link-list">
                                    <div>
                                        <span class="footer-list-header footer-list-header-toggle has-bg-img-after">
                                            join our team
                                        </span>
                                        
                                                <ul class="list-clean footer-link-list-sub">
                                                    
                                                <li>
                                                    <a href="https://www.randstad.in/job-seeker/our-offices/" target="_self">our offices</a>
                                                </li>
                                            
                                                </ul>
                                            
                                    </div>
                                    
                                </div>
                            
                                <div class="footer-link-list">
                                    <div>
                                        <span class="footer-list-header footer-list-header-toggle has-bg-img-after">
                                            workforce360
                                        </span>
                                        
                                                <ul class="list-clean footer-link-list-sub">
                                                    
                                                <li>
                                                    <a href="https://www.randstad.in/workforce360/archives/?th=90" target="_self">strategic talent management</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/workforce360/archives/?th=5" target="_self">HR & leadership</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/workforce360/archives/?th=6" target="_self">flexibility & labour market</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/employer-brand-research/employer-branding/" target="_self">employer branding</a>
                                                </li>
                                            
                                                <li>
                                                    <a href="https://www.randstad.in/workforce360/archives/" target="_self">archives</a>
                                                </li>
                                            
                                                </ul>
                                            
                                    </div>
                                    
                                </div>
                            
                                <div class="footer-link-list">
                                    <div>
                                        <span class="footer-list-header footer-list-header-toggle has-bg-img-after">
                                            women at work
                                        </span>
                                        
                                                <ul class="list-clean footer-link-list-sub">
                                                    
                                                <li>
                                                    <a href="https://www.randstad.in/women-at-work/voices/" target="_self">voices</a>
                                                </li>
                                            
                                                </ul>
                                            
                                    </div>
                                    
                                </div>
                            
                                    </div>
                                </div>  -->
                            
                    
                    </div>
        <!--    <div class="footer-main-col footer-search">
                <div class="searchbar">
                    <div id="ctl09_ctl05_ctl01_Panel1" class="quick-search-wrapper" onkeypress="javascript:return WebForm_FireDefaultButton(event, &#39;ctl09_ctl05_ctl01_SearchButton&#39;)">
	
    <label for="ctl09_ctl05_ctl01_SearchTextBox" id="ctl09_ctl05_ctl01_SearchTextBoxLabel"></label>
    <input name="ctl09$ctl05$ctl01$SearchTextBox" type="text" maxlength="100" id="ctl09_ctl05_ctl01_SearchTextBox" class="QuickSearchInput" placeholder="search this site" />
    <a id="ctl09_ctl05_ctl01_SearchButton" class="btn btn-prim icon-arrow-right" href="javascript:__doPostBack(&#39;ctl09$ctl05$ctl01$SearchButton&#39;,&#39;&#39;)">search</a>
    

</div>

                </div>
            </div> -->
        <!--    <div class="footer-main-custom-wrapper">
                <div class="prim-social-bar prim-social-bar-small">
                    <ul class="list-clean">
                        <li id="ctl09_ctl05_LinkedinLi">
                            <a id="ctl09_ctl05_LinkedinHyperLink" class="li has-bg-img has-bg-img-before" href="https://www.linkedin.com/company/2554444/" target="_blank">LinkedIn</a>
                        </li>
                        <li id="ctl09_ctl05_YoutubeLi">
                            <a id="ctl09_ctl05_YoutubeHyperLink" class="yt has-bg-img has-bg-img-before" href="https://www.youtube.com/channel/UCzgSePqFizttduqTo8iq9tA" target="_blank">Youtube</a>
                        </li>
                        <li id="ctl09_ctl05_FacebookLi">
                            <a id="ctl09_ctl05_FacebookHyperLink" class="fb has-bg-img has-bg-img-before" href="https://www.facebook.com/RandstadIndia/" target="_blank">Facebook</a>
                        </li>
                        <li id="ctl09_ctl05_TwitterLi">
                            <a id="ctl09_ctl05_TwitterHyperLink" class="tw has-bg-img has-bg-img-before" href="https://twitter.com/RandstadIndia" target="_blank">Twitter</a>
                        </li>
                        
                        
                        
                        
                    </ul>
                </div>
                <div id="ctl09_ctl05_FooterAdditionalLinksWrapper" class="footer-main-custom">
                            <ul class="footer-link-list list-clean">
                                
                            <li>
                                <a href="https://www.randstad.in/terms-and-conditions/" target="_self">terms & conditions</a>
                            </li>
                        
                            <li>
                                <a href="https://www.randstad.in/contact-us/" target="_self">contact us</a>
                            </li>
                        
                            <li>
                                <a href="https://www.randstad.in/cookies/" target="_self">cookies</a>
                            </li>
                        
                            <li>
                                <a href="https://www.randstad.in/privacy-statement/" target="_self">data protection statement</a>
                            </li>
                        
                            <li>
                                <a href="https://www.randstad.in/misconduct-reporting-procedure/" target="_self">misconduct reporting procedure</a>
                            </li>
                        
                            <li>
                                <a href="https://www.randstad.in/be-aware/" target="_self">be aware</a>
                            </li>
                        
                            <li>
                                <a href="https://www.randstad.in/sitemap/" target="_self">sitemap</a>
                            </li>
                        
                            </ul>
                        </div>
            </div> -->
         <!--   <div class="trade-mark-wrapper">
                <div id="ctl09_ctl05_ctl02_WrapperDiv" class="html-loader-div ">
    
    
    <p>registered office:&nbsp;Randstad India&nbsp;Private Limited, CIN U74210TN1992PTC023097, /&nbsp;Randstad House, Old No. 5 &amp; 5A, New No. 9,&nbsp;Pycrofts Garden Road,&nbsp;Nungambakkam,&nbsp;Chennai&nbsp;TAMIL NADU, INDIA - 600 006&nbsp;&nbsp;&nbsp; &nbsp;</p>
<p>RANDSTAD, <img alt="" src="../../ugc/img/about/randstad_wings_100px.png" style="height: 10px;" />, HUMAN FORWARD and SHAPING THE WORLD OF WORK are registered trademarks of &copy; Randstad N.V.2019</p>
<p><span style="font-size: 0.875em;">Security Advice :</span></p>
<p>
Randstad India does not charge any fee at any stage of its recruitment process from the candidate nor allows their employees to collect any fees from any candidates.
<a href="https://www.randstad.in/job-seeker/security-advice/" title="Security Advice">Click here to know more</a>&nbsp;</p>
<div>&nbsp;</div>
    
</div>

                <a href="https://www.bitagency.com/" target="_blank" title="Development and Hosting by Bit Agency - new window" class="footer-link-greyed-out">Development and Hosting by Bit Agency</a>
            </div> -->
        </div>
    </footer>
</div>

    </div>
</div>



<div class="sb-slidebar sb-right sb-width-custom sb-style">
    
    
            <ul class="nav-global-small list-clean" data-bit-mobile-menu="">
                
            <li>
                <a href="https://www.randstad.in/job-seeker/">job seeker</a>
                
                        <span class="nav-global-small-toggle has-bg-img">toggle</span>
                        <ul class="list-clean nav-global-small-sub">
                            
                        <li>
                            <a href="https://www.randstad.in/jobs/" target="_self">find a job</a>
                        </li>
                    
                        <li>
                            <a href="https://www.randstad.in/my-randstad/register/" target="_self">submit your CV</a>
                        </li>
                    
                        <li>
                            <a href="https://www.randstad.in/job-seeker/career-hub/">career hub</a>
                        </li>
                    
                        <li>
                            <a href="https://www.randstad.in/job-seeker/areas-of-expertise/">areas of expertise</a>
                        </li>
                    
                        <li>
                            <a href="https://www.randstad.in/job-seeker/our-offices/">our offices</a>
                        </li>
                    
                        <li>
                            <a href="https://www.randstad.in/job-seeker/security-advice/">security advice</a>
                        </li>
                    
                        </ul>
                    
            </li>
        
            <li>
                <a href="https://www.randstad.in/employers/">employers</a>
                
                        <span class="nav-global-small-toggle has-bg-img">toggle</span>
                        <ul class="list-clean nav-global-small-sub">
                            
                        <li>
                            <a href="index.html">submit a job</a>
                        </li>
                    
                        <li>
                            <a href="https://www.randstad.in/employers/request-a-call-back/">request a call back</a>
                        </li>
                    
                        <li>
                            <a href="https://www.randstad.in/employers/areas-of-expertise/">areas of expertise</a>
                        </li>
                    
                        <li>
                            <a href="https://www.randstad.in/employers/our-offices/">our offices</a>
                        </li>
                    
                        <li>
                            <a href="https://www.randstad.in/employers/randstad-insights/">randstad insights</a>
                        </li>
                    
                        </ul>
                    
            </li>
        
            <li>
                <a href="https://www.randstad.in/about-us/">about us</a>
                
                        <span class="nav-global-small-toggle has-bg-img">toggle</span>
                        <ul class="list-clean nav-global-small-sub">
                            
                        <li>
                            <a href="https://www.randstad.in/about-us/our-history/">our history</a>
                        </li>
                    
                        <li>
                            <a href="https://www.randstad.in/about-us/our-sponsorships/">our sponsorships</a>
                        </li>
                    
                        <li>
                            <a href="https://www.randstad.in/about-us/social-responsibility/">social responsibility</a>
                        </li>
                    
                        <li>
                            <a href="https://www.randstad.in/about-us/press-releases/">press releases</a>
                        </li>
                    
                        <li>
                            <a href="https://www.randstad.in/about-us/randstad-in-the-news/">randstad in the news</a>
                        </li>
                    
                        </ul>
                    
            </li>
        
            <li>
                <a href="https://www.randstad.in/join-our-team/">join our team</a>
                
            </li>
        
            <li>
                <a href="https://www.randstad.in/workforce360/">workforce360</a>
                
                        <span class="nav-global-small-toggle has-bg-img">toggle</span>
                        <ul class="list-clean nav-global-small-sub">
                            
                        <li>
                            <a href="https://www.randstad.in/workforce360/archives/?th=90" target="_self">strategic talent management</a>
                        </li>
                    
                        <li>
                            <a href="https://www.randstad.in/workforce360/archives/?th=5" target="_self">HR & leadership</a>
                        </li>
                    
                        <li>
                            <a href="https://www.randstad.in/workforce360/archives/?th=6" target="_self">flexibility & labour market</a>
                        </li>
                    
                        <li>
                            <a href="https://www.randstad.in/workforce360/archives/?th=7" target="_self">employer branding</a>
                        </li>
                    
                        <li>
                            <a href="https://www.randstad.in/workforce360/events/">events</a>
                        </li>
                    
                        <li>
                            <a href="https://www.randstad.in/workforce360/archives/">archives</a>
                        </li>
                    
                        </ul>
                    
            </li>
        
            <li>
                <a href="https://www.randstad.in/my-randstad/">my Randstad</a>
                
                        <span class="nav-global-small-toggle has-bg-img">toggle</span>
                        <ul class="list-clean nav-global-small-sub">
                            
                        <li>
                            <a href="https://www.randstad.in/my-randstad/my-randstad/">my Randstad</a>
                        </li>
                    
                        <li>
                            <a href="https://www.randstad.in/my-randstad/my-profile/">my profile</a>
                        </li>
                    
                        <li>
                            <a href="https://www.randstad.in/jobs/" target="_self">find a job</a>
                        </li>
                    
                        <li>
                            <a href="https://www.randstad.in/job-seeker/career-hub/" target="_self">career hub</a>
                        </li>
                    
                        <li>
                            <a href="https://www.randstad.in/job-seeker/areas-of-expertise/" target="_self">areas of expertise</a>
                        </li>
                    
                        <li>
                            <a href="https://www.randstad.in/job-seeker/our-offices/" target="_self">our offices</a>
                        </li>
                    
                        </ul>
                    
            </li>
        
            <li>
                <a href="https://www.randstad.in/employer-brand-research/">employer brand research</a>
                
                        <span class="nav-global-small-toggle has-bg-img">toggle</span>
                        <ul class="list-clean nav-global-small-sub">
                            
                        <li>
                            <a href="https://www.randstad.in/employer-brand-research/about-randstad-award/">About Randstad Award</a>
                        </li>
                    
                        <li>
                            <a href="https://www.randstad.in/employer-brand-research/randstad-award-2018/">Randstad Award 2018</a>
                        </li>
                    
                        <li>
                            <a href="https://www.randstad.in/employer-brand-research/request-for-a-country-report/">Request for a country report</a>
                        </li>
                    
                        <li>
                            <a href="https://www.randstad.in/employer-brand-research/employer-branding/">employer branding</a>
                        </li>
                    
                        </ul>
                    
            </li>
        
            <li>
                <a href="https://www.randstad.in/randstad-insights/">randstad insights</a>
                
                        <span class="nav-global-small-toggle has-bg-img">toggle</span>
                        <ul class="list-clean nav-global-small-sub">
                            
                        <li>
                            <a href="https://www.randstad.in/randstad-insights/workforce-gender-parity-a-4-point-agenda-for-indias-surge/">Workforce Gender Parity - A 4-point Agenda for India’s Surge</a>
                        </li>
                    
                        </ul>
                    
            </li>
        
            <li>
                <a href="https://www.randstad.in/futurist-chro/">futurist chro</a>
                
                        <span class="nav-global-small-toggle has-bg-img">toggle</span>
                        <ul class="list-clean nav-global-small-sub">
                            
                        <li>
                            <a href="https://www.randstad.in/futurist-chro/hr-transformation/">hr transformation</a>
                        </li>
                    
                        <li>
                            <a href="https://www.randstad.in/futurist-chro/managing-millenials/">managing millenials</a>
                        </li>
                    
                        <li>
                            <a href="https://www.randstad.in/futurist-chro/workplace-of-the-future/">workplace of the future</a>
                        </li>
                    
                        <li>
                            <a href="https://www.randstad.in/futurist-chro/hr-and-technology/">hr and technology</a>
                        </li>
                    
                        <li>
                            <a href="https://www.randstad.in/futurist-chro/randstad-five-forces-redefining-the-world-of-hr-e_book.pdf">Randstad - Five Forces Redefining the World of HR - E_book</a>
                        </li>
                    
                        </ul>
                    
            </li>
        
                <li><a href="https://www.randstad.in/contact-us/">contact us</a></li>
                <li><a href="https://www.randstad.in/worldwide/">Randstad worldwide</a></li>
            </ul>
        
</div>





    
<script type="text/javascript">
//<![CDATA[
var Page_ValidationSummaries =  new Array(document.getElementById("ctl09_ctl04_ctl01_FormValidationSummary"));
var Page_Validators =  new Array(document.getElementById("ctl09_ctl02_UserNameRequired"), document.getElementById("ctl09_ctl02_PasswordRequired"), document.getElementById("ctl09_ctl04_ctl01_CmsFormValidator"));
//]]>
</script>

<script type="text/javascript">
//<![CDATA[
var ctl09_ctl02_UserNameRequired = document.all ? document.all["ctl09_ctl02_UserNameRequired"] : document.getElementById("ctl09_ctl02_UserNameRequired");
ctl09_ctl02_UserNameRequired.controltovalidate = "ctl09_ctl02_UserNameTextBox";
ctl09_ctl02_UserNameRequired.errormessage = "Email address (username) is required";
ctl09_ctl02_UserNameRequired.display = "Dynamic";
ctl09_ctl02_UserNameRequired.validationGroup = "SimpleLoginPanel";
ctl09_ctl02_UserNameRequired.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
ctl09_ctl02_UserNameRequired.initialvalue = "";
var ctl09_ctl02_PasswordRequired = document.all ? document.all["ctl09_ctl02_PasswordRequired"] : document.getElementById("ctl09_ctl02_PasswordRequired");
ctl09_ctl02_PasswordRequired.controltovalidate = "ctl09_ctl02_PasswordTextBox";
ctl09_ctl02_PasswordRequired.errormessage = "Password is required";
ctl09_ctl02_PasswordRequired.display = "Dynamic";
ctl09_ctl02_PasswordRequired.validationGroup = "SimpleLoginPanel";
ctl09_ctl02_PasswordRequired.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
ctl09_ctl02_PasswordRequired.initialvalue = "";
var ctl09_ctl04_ctl01_FormValidationSummary = document.all ? document.all["ctl09_ctl04_ctl01_FormValidationSummary"] : document.getElementById("ctl09_ctl04_ctl01_FormValidationSummary");
ctl09_ctl04_ctl01_FormValidationSummary.validationGroup = "ClientSubmitRequest";
var ctl09_ctl04_ctl01_CmsFormValidator = document.all ? document.all["ctl09_ctl04_ctl01_CmsFormValidator"] : document.getElementById("ctl09_ctl04_ctl01_CmsFormValidator");
ctl09_ctl04_ctl01_CmsFormValidator.display = "None";
ctl09_ctl04_ctl01_CmsFormValidator.validationGroup = "ClientSubmitRequest";
ctl09_ctl04_ctl01_CmsFormValidator.evaluationfunction = "CustomValidatorEvaluateIsValid";
//]]>
</script>


<script type="text/javascript">
//<![CDATA[

var Page_ValidationActive = false;
if (typeof(ValidatorOnLoad) == "function") {
    ValidatorOnLoad();
}

function ValidatorOnSubmit() {
    if (Page_ValidationActive) {
        return ValidatorCommonOnSubmit();
    }
    else {
        return true;
    }
}
        
(function(id) {
    var e = document.getElementById(id);
    if (e) {
        e.dispose = function() {
            Array.remove(Page_ValidationSummaries, document.getElementById(id));
        }
        e = null;
    }
})('ctl09_ctl04_ctl01_FormValidationSummary');

document.getElementById('ctl09_ctl02_UserNameRequired').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ctl09_ctl02_UserNameRequired'));
}
Sys.Application.add_init(function() {
    $create(Sys.Extended.UI.TextBoxWatermarkBehavior, {"ClientStateFieldID":"ctl09_ctl02_UserNameWatermarkExtender_ClientState","WatermarkCssClass":"watermark","WatermarkText":"username","id":"ctl09_ctl02_UserNameWatermarkExtender"}, null, null, $get("ctl09_ctl02_UserNameTextBox"));
});

document.getElementById('ctl09_ctl02_PasswordRequired').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ctl09_ctl02_PasswordRequired'));
}

document.getElementById('ctl09_ctl04_ctl01_CmsFormValidator').dispose = function() {
    Array.remove(Page_Validators, document.getElementById('ctl09_ctl04_ctl01_CmsFormValidator'));
}
//]]>
</script>
</form>
    <script type="text/javascript">
    (function (n) {
        var u = window.location.href;
        var p = u.split("https://www.randstad.in/")[0];
        var t = n.createElement("script"), i;
        t.type = "text/javascript";
        t.async = !0;
        t.src = p + "//dashboard.whoisvisiting.com/who.js";
        i = n.getElementsByTagName("script")[0];
        i.parentNode.insertBefore(t, i)
    })(document);

        var whoparam = whoparam || [];
        whoparam.push(["AcNo", "49a4f5305328407695ca493ff9ff46df"]);
        whoparam.push(["SendHit", ""]
    );
</script>
<!-- Google Code for Remarketing Tag -->
<!--------------------------------------------------
Remarketing tags may not be associated with personally identifiable information or placed on pages related to sensitive categories. See more information and instructions on how to setup the tag on: http://google.com/ads/remarketingsetup
--------------------------------------------------->
<script type="text/javascript">
/* <![CDATA[ */
var google_conversion_id = 882227598;
var google_custom_params = window.google_tag_params;
var google_remarketing_only = true;
/* ]]> */
</script>
<script type="text/javascript" src="../../../www.googleadservices.com/pagead/f.txt">
</script>
<noscript>
<div style="display:inline;">
<img height="1" width="1" style="border-style:none;" alt="" src="http://googleads.g.doubleclick.net/pagead/viewthroughconversion/882227598/?guid=ON&amp;script=0"/>
</div>
</noscript>
</body>

<!-- Mirrored from www.randstad.in/employers/submit-a-job/ by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 16 May 2019 12:23:24 GMT -->
</html>